self.__BUILD_MANIFEST = {
  "__rewrites": {
    "afterFiles": [
      {
        "source": "/api/webhook/event"
      },
      {
        "source": "/api/v1/tools/selection"
      },
      {
        "source": "/api/v1/tools/image"
      },
      {
        "source": "/api/v1/tools/video"
      },
      {
        "source": "/api/v1/tools/listing"
      },
      {
        "source": "/api/v1/tools/pricing"
      },
      {
        "source": "/api/v1/tools/customer-service"
      },
      {
        "source": "/api/v1/tools/scrape"
      },
      {
        "source": "/api/v1/tools/scrape/batch"
      },
      {
        "source": "/api/v1/tools/ads/create"
      },
      {
        "source": "/api/v1/ai/:path*"
      },
      {
        "source": "/api/v1/auth/:path*",
        "destination": "/api/v1/auth/:path*"
      },
      {
        "source": "/api/auth/:path*",
        "destination": "/api/auth/:path*"
      },
      {
        "source": "/api/miaoshou/:path*"
      }
    ],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/_app",
    "/_error"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()