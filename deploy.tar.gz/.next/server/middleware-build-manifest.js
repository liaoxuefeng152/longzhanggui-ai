globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/2b1bd0993a820797.js",
    "static/chunks/ce51e5d050c8ed9f.js",
    "static/chunks/c2c2eb2a3bfd9c35.js",
    "static/chunks/141ff9e95082f8bb.js",
    "static/chunks/turbopack-14da307c78b3faab.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];