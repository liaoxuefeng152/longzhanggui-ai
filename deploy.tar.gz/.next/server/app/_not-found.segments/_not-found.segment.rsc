1:"$Sreact.fragment"
2:I[96871,["/_next/static/chunks/3c53782416237f37.js","/_next/static/chunks/66bbaf9ca461ebb7.js"],"default"]
3:I[58525,["/_next/static/chunks/3c53782416237f37.js","/_next/static/chunks/66bbaf9ca461ebb7.js"],"default"]
0:{"buildId":"C9_wdntW6d7cSZO0x14dS","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
