1:"$Sreact.fragment"
2:I[47161,["/_next/static/chunks/3c53782416237f37.js","/_next/static/chunks/66bbaf9ca461ebb7.js"],"ViewportBoundary"]
3:I[47161,["/_next/static/chunks/3c53782416237f37.js","/_next/static/chunks/66bbaf9ca461ebb7.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
5:I[16327,["/_next/static/chunks/3c53782416237f37.js","/_next/static/chunks/66bbaf9ca461ebb7.js"],"IconMark"]
0:{"buildId":"C9_wdntW6d7cSZO0x14dS","rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"龙掌柜智能运营系统"}],["$","meta","1",{"name":"description","content":"专为TK东南亚跨境场景设计的智能运营平台，提供SKILL、模型调用、Prompt管理等核心能力"}],["$","meta","2",{"name":"keywords","content":"老板,跨境AI,AI中台,TK东南亚,SKILL,Prompt管理,模型路由,AI客服,自推广"}],["$","link","3",{"rel":"icon","href":"/favicon.ico?favicon.0b3bf435.ico","sizes":"256x256","type":"image/x-icon"}],["$","$L5","4",{}]]}]}]}],null]}],"loading":null,"isPartial":false}
