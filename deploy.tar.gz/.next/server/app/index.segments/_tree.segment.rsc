:HL["/_next/static/chunks/afc80a9262b95c88.css","style"]
0:{"buildId":"C9_wdntW6d7cSZO0x14dS","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
