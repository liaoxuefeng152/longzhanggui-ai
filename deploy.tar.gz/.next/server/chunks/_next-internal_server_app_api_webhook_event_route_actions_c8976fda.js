module.exports=[32547,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_webhook_event_route_actions_c8976fda.js.map