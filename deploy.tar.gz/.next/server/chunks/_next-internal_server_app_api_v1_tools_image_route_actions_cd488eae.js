module.exports=[21147,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_tools_image_route_actions_cd488eae.js.map