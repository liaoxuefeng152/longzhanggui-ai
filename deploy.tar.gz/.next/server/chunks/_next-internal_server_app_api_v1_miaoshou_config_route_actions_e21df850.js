module.exports=[46632,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_miaoshou_config_route_actions_e21df850.js.map