module.exports=[64615,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_feishu_webhook_route_actions_fb455a0c.js.map