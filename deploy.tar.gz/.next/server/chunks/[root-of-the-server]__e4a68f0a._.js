module.exports=[70406,(e,t,r)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},93695,(e,t,r)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},18622,(e,t,r)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},24725,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},14747,(e,t,r)=>{t.exports=e.x("path",()=>require("path"))},94824,(e,t,r)=>{t.exports=e.x("better-sqlite3-6af3159004069310",()=>require("better-sqlite3-6af3159004069310"))},22734,(e,t,r)=>{t.exports=e.x("fs",()=>require("fs"))},84501,e=>{"use strict";var t=e.i(94824),r=e.i(14747),a=e.i(22734);let n=r.default.join(process.cwd(),"data","lobster.db"),s=r.default.dirname(n);a.default.existsSync(s)||a.default.mkdirSync(s,{recursive:!0});let o=null;function i(){return o||((o=new t.default(n)).pragma("journal_mode = WAL"),o.pragma("foreign_keys = ON"),function(e){e.exec(`
    CREATE TABLE IF NOT EXISTS platforms (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      platform TEXT NOT NULL,
      credentials TEXT DEFAULT '{}',
      status TEXT DEFAULT 'disconnected',
      last_sync TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    )
  `),e.exec(`
    CREATE TABLE IF NOT EXISTS miaoshou_config (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      phone TEXT NOT NULL,
      password TEXT NOT NULL,
      cookies TEXT,
      status TEXT DEFAULT 'disconnected',
      last_sync TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    )
  `);try{e.exec("ALTER TABLE miaoshou_config ADD COLUMN app_key TEXT"),e.exec("ALTER TABLE miaoshou_config ADD COLUMN app_secret TEXT")}catch(e){}e.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      username TEXT NOT NULL UNIQUE,
      password TEXT NOT NULL,
      email TEXT,
      role TEXT DEFAULT 'client',
      avatar TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    )
  `),e.exec(`
    CREATE TABLE IF NOT EXISTS products (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      name_en TEXT,
      sku TEXT,
      category TEXT,
      cost_price REAL DEFAULT 0,
      price REAL DEFAULT 0,
      stock INTEGER DEFAULT 0,
      status TEXT DEFAULT 'draft',
      source TEXT,
      source_url TEXT,
      supplier_name TEXT,
      supplier_id TEXT,
      images TEXT DEFAULT '[]',
      video_url TEXT,
      weight REAL,
      dimensions TEXT,
      description TEXT,
      description_en TEXT,
      keywords TEXT,
      attributes TEXT DEFAULT '{}',
      shop_id TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    )
  `),e.exec(`
    CREATE TABLE IF NOT EXISTS collection_products (
      id TEXT PRIMARY KEY,
      collection_id TEXT,
      product_id TEXT,
      product_name TEXT NOT NULL,
      source TEXT,
      source_url TEXT,
      source_id TEXT,
      supplier_name TEXT,
      cost_price REAL DEFAULT 0,
      images TEXT DEFAULT '[]',
      category TEXT,
      claimed INTEGER DEFAULT 0,
      claimed_by TEXT,
      claimed_at TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    )
  `),e.exec(`
    CREATE TABLE IF NOT EXISTS feishu_config (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      app_id TEXT NOT NULL,
      app_secret TEXT NOT NULL,
      bot_name TEXT,
      webhook_url TEXT,
      push_enabled INTEGER DEFAULT 0,
      alert_enabled INTEGER DEFAULT 1,
      alert_threshold INTEGER DEFAULT 10,
      templates TEXT DEFAULT '{}',
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    )
  `),e.exec(`
    CREATE TABLE IF NOT EXISTS import_history (
      id TEXT PRIMARY KEY,
      type TEXT NOT NULL,
      file_name TEXT,
      status TEXT DEFAULT 'pending',
      total_rows INTEGER DEFAULT 0,
      success_rows INTEGER DEFAULT 0,
      error_rows INTEGER DEFAULT 0,
      error_log TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      completed_at TEXT
    )
  `),0===e.prepare("SELECT COUNT(*) as count FROM users WHERE role = ?").get("admin").count&&e.prepare(`
      INSERT INTO users (id, username, password, email, role) VALUES (?, ?, ?, ?, ?)
    `).run("admin","admin","admin123","admin@example.com","admin"),0===e.prepare("SELECT COUNT(*) as count FROM feishu_config").get().count&&e.prepare(`
      INSERT INTO feishu_config (app_id, app_secret, bot_name, push_enabled, alert_enabled)
      VALUES (?, ?, ?, ?, ?)
    `).run("","","龙掌柜跨境AI全能助手",0,1),console.log("[DB] Database tables initialized")}(o)),o}e.s(["getDb",()=>i])},13189,e=>{"use strict";var t=e.i(2710),r=e.i(35147),a=e.i(55688),n=e.i(87453),s=e.i(3771),o=e.i(47937),i=e.i(5457),T=e.i(17598),d=e.i(41045),l=e.i(71952),E=e.i(59300),u=e.i(85005),c=e.i(69628),p=e.i(3185),R=e.i(47811),A=e.i(93695);e.i(635);var m=e.i(28214),h=e.i(78869),_=e.i(84501);async function x(){try{let e=(0,_.getDb)().prepare("SELECT * FROM feishu_config WHERE id = 1").get();if(!e)return h.NextResponse.json({success:!0,data:{appId:"",appSecret:"",botName:"龙掌柜跨境AI全能助手",enabled:!1}});return h.NextResponse.json({success:!0,data:e})}catch(e){return console.error("获取飞书配置失败:",e),h.NextResponse.json({success:!1,error:"获取配置失败"},{status:500})}}async function f(e){try{let t=await e.json(),{appId:r,appSecret:a,botName:n,enabled:s}=t;if(!r||!a)return h.NextResponse.json({success:!1,error:"AppID和AppSecret不能为空"},{status:400});return(0,_.getDb)().prepare(`
      INSERT OR REPLACE INTO feishu_config (id, app_id, app_secret, bot_name, enabled, verification_token, updated_at)
      VALUES (
        1,
        ?,
        ?,
        ?,
        ?,
        ?,
        datetime('now')
      )
    `).run(r,a,n||"龙掌柜跨境AI全能助手",+!!s,t.verificationToken||null),h.NextResponse.json({success:!0,message:"配置保存成功"})}catch(e){return console.error("保存飞书配置失败:",e),h.NextResponse.json({success:!1,error:"保存配置失败"},{status:500})}}e.s(["GET",()=>x,"PUT",()=>f],3451);var L=e.i(3451);let N=new t.AppRouteRouteModule({definition:{kind:r.RouteKind.APP_ROUTE,page:"/api/feishu/config/route",pathname:"/api/feishu/config",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/src/app/api/feishu/config/route.ts",nextConfigOutput:"standalone",userland:L}),{workAsyncStorage:X,workUnitAsyncStorage:g,serverHooks:U}=N;function w(){return(0,a.patchFetch)({workAsyncStorage:X,workUnitAsyncStorage:g})}async function I(e,t,a){N.isDev&&(0,n.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let h="/api/feishu/config/route";h=h.replace(/\/index$/,"")||"/";let _=await N.prepare(e,t,{srcPage:h,multiZoneDraftMode:!1});if(!_)return t.statusCode=400,t.end("Bad Request"),null==a.waitUntil||a.waitUntil.call(a,Promise.resolve()),null;let{buildId:x,params:f,nextConfig:L,parsedUrl:X,isDraftMode:g,prerenderManifest:U,routerServerContext:w,isOnDemandRevalidate:I,revalidateOnlyGenerated:v,resolvedPathname:D,clientReferenceManifest:O,serverActionsManifest:C}=_,F=(0,i.normalizeAppPath)(h),y=!!(U.dynamicRoutes[F]||U.routes[D]),b=async()=>((null==w?void 0:w.render404)?await w.render404(e,t,X,!1):t.end("This page could not be found"),null);if(y&&!g){let e=!!U.routes[D],t=U.dynamicRoutes[F];if(t&&!1===t.fallback&&!e){if(L.experimental.adapterPath)return await b();throw new A.NoFallbackError}}let S=null;!y||N.isDev||g||(S="/index"===(S=D)?"/":S);let P=!0===N.isDev||!y,k=y&&!P;C&&O&&(0,o.setManifestsSingleton)({page:h,clientReferenceManifest:O,serverActionsManifest:C});let j=e.method||"GET",M=(0,s.getTracer)(),q=M.getActiveScopeSpan(),H={params:f,prerenderManifest:U,renderOpts:{experimental:{authInterrupts:!!L.experimental.authInterrupts},cacheComponents:!!L.cacheComponents,supportsDynamicResponse:P,incrementalCache:(0,n.getRequestMeta)(e,"incrementalCache"),cacheLifeProfiles:L.cacheLife,waitUntil:a.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,r,a,n)=>N.onRequestError(e,t,a,n,w)},sharedContext:{buildId:x}},B=new T.NodeNextRequest(e),K=new T.NodeNextResponse(t),G=d.NextRequestAdapter.fromNodeNextRequest(B,(0,d.signalFromNodeResponse)(t));try{let o=async e=>N.handle(G,H).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let r=M.getRootSpanAttributes();if(!r)return;if(r.get("next.span_type")!==l.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${r.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let a=r.get("next.route");if(a){let t=`${j} ${a}`;e.setAttributes({"next.route":a,"http.route":a,"next.span_name":t}),e.updateName(t)}else e.updateName(`${j} ${h}`)}),i=!!(0,n.getRequestMeta)(e,"minimalMode"),T=async n=>{var s,T;let d=async({previousCacheEntry:r})=>{try{if(!i&&I&&v&&!r)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let s=await o(n);e.fetchMetrics=H.renderOpts.fetchMetrics;let T=H.renderOpts.pendingWaitUntil;T&&a.waitUntil&&(a.waitUntil(T),T=void 0);let d=H.renderOpts.collectedTags;if(!y)return await (0,u.sendResponse)(B,K,s,H.renderOpts.pendingWaitUntil),null;{let e=await s.blob(),t=(0,c.toNodeOutgoingHttpHeaders)(s.headers);d&&(t[R.NEXT_CACHE_TAGS_HEADER]=d),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let r=void 0!==H.renderOpts.collectedRevalidate&&!(H.renderOpts.collectedRevalidate>=R.INFINITE_CACHE)&&H.renderOpts.collectedRevalidate,a=void 0===H.renderOpts.collectedExpire||H.renderOpts.collectedExpire>=R.INFINITE_CACHE?void 0:H.renderOpts.collectedExpire;return{value:{kind:m.CachedRouteKind.APP_ROUTE,status:s.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:r,expire:a}}}}catch(t){throw(null==r?void 0:r.isStale)&&await N.onRequestError(e,t,{routerKind:"App Router",routePath:h,routeType:"route",revalidateReason:(0,E.getRevalidateReason)({isStaticGeneration:k,isOnDemandRevalidate:I})},!1,w),t}},l=await N.handleResponse({req:e,nextConfig:L,cacheKey:S,routeKind:r.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:U,isRoutePPREnabled:!1,isOnDemandRevalidate:I,revalidateOnlyGenerated:v,responseGenerator:d,waitUntil:a.waitUntil,isMinimalMode:i});if(!y)return null;if((null==l||null==(s=l.value)?void 0:s.kind)!==m.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==l||null==(T=l.value)?void 0:T.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});i||t.setHeader("x-nextjs-cache",I?"REVALIDATED":l.isMiss?"MISS":l.isStale?"STALE":"HIT"),g&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let A=(0,c.fromNodeOutgoingHttpHeaders)(l.value.headers);return i&&y||A.delete(R.NEXT_CACHE_TAGS_HEADER),!l.cacheControl||t.getHeader("Cache-Control")||A.get("Cache-Control")||A.set("Cache-Control",(0,p.getCacheControlHeader)(l.cacheControl)),await (0,u.sendResponse)(B,K,new Response(l.value.body,{headers:A,status:l.value.status||200})),null};q?await T(q):await M.withPropagatedContext(e.headers,()=>M.trace(l.BaseServerSpan.handleRequest,{spanName:`${j} ${h}`,kind:s.SpanKind.SERVER,attributes:{"http.method":j,"http.target":e.url}},T))}catch(t){if(t instanceof A.NoFallbackError||await N.onRequestError(e,t,{routerKind:"App Router",routePath:F,routeType:"route",revalidateReason:(0,E.getRevalidateReason)({isStaticGeneration:k,isOnDemandRevalidate:I})},!1,w),y)throw t;return await (0,u.sendResponse)(B,K,new Response(null,{status:500})),null}}e.s(["handler",()=>I,"patchFetch",()=>w,"routeModule",()=>N,"serverHooks",()=>U,"workAsyncStorage",()=>X,"workUnitAsyncStorage",()=>g],13189)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__e4a68f0a._.js.map