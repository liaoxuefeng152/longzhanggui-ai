module.exports=[18622,(e,t,r)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},70406,(e,t,r)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},93695,(e,t,r)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},16494,e=>e.a(async(t,r)=>{try{let t=await e.y("coze-coding-dev-sdk-e40545b728faa7b1");e.n(t),r()}catch(e){r(e)}},!0),14353,e=>e.a(async(t,r)=>{try{var n=e.i(16494),a=t([n]);[n]=a.then?(await a)():a;let s=`你是龙掌柜选品分析专家，专注于东南亚跨境电商市场。

## 分析框架

### 1. 市场趋势分析
- TikTok Shop、Shopee、Lazada 热门趋势
- 季节性产品机会
- 新兴类目机会

### 2. 竞品分析维度
- 价格区间分析
- 销量预估
- 评价分析
- 差异化机会

### 3. 蓝海类目识别
- 低竞争高需求
- 供应链优势
- 利润空间评估

### 4. 风险评估
- 合规风险
- 物流风险
- 库存风险

## 输出格式
使用Markdown格式，包含表格、列表、数据对比。

## 目标市场
- 泰国 (TH)
- 越南 (VN)
- 马来西亚 (MY)
- 印尼 (ID)
- 菲律宾 (PH)

请基于用户需求，提供专业的选品分析报告。`;async function o(e){try{let{category:t,targetMarket:r,budget:a,keywords:o,specificRequest:i}=await e.json(),l=`
请进行选品分析：

${t?`**类目**: ${t}`:""}
${r?`**目标市场**: ${r}`:"目标市场：泰国、越南、马来西亚、印尼、菲律宾（全市场）"}
${a?`**预算范围**: ${a}元`:""}
${o?.length?`**关键词**: ${o.join(", ")}`:""}
${i?`**具体需求**: ${i}`:""}

请提供：
1. 市场趋势分析
2. 推荐3-5个选品方向
3. 每个方向的竞品分析
4. 利润空间评估
5. 风险提示
6. 行动建议
`,d=n.HeaderUtils.extractForwardHeaders(e.headers),c=new n.Config,u=new n.LLMClient(c,d),p=new TextEncoder,h=new ReadableStream({async start(e){try{e.enqueue(p.encode(`data: ${JSON.stringify({type:"start",message:"开始选品分析..."})}

`));let t=u.stream([{role:"system",content:s},{role:"user",content:l}],{model:"doubao-seed-1-8-251228",temperature:.7}),r="";for await(let n of t)if(n.content){let t=n.content.toString();r+=t,e.enqueue(p.encode(`data: ${JSON.stringify({type:"content",content:t})}

`))}e.enqueue(p.encode(`data: ${JSON.stringify({type:"done",fullResponse:r})}

`)),e.close()}catch(t){console.error("Selection analysis error:",t),e.enqueue(p.encode(`data: ${JSON.stringify({type:"error",message:"分析失败，请重试"})}

`)),e.close()}}});return new Response(h,{headers:{"Content-Type":"text/event-stream","Cache-Control":"no-cache",Connection:"keep-alive"}})}catch(e){return console.error("Selection API error:",e),new Response(JSON.stringify({detail:"服务器内部错误"}),{status:500,headers:{"Content-Type":"application/json"}})}}e.s(["POST",()=>o]),r()}catch(e){r(e)}},!1),75655,e=>e.a(async(t,r)=>{try{var n=e.i(2710),a=e.i(35147),o=e.i(55688),s=e.i(87453),i=e.i(3771),l=e.i(47937),d=e.i(5457),c=e.i(17598),u=e.i(41045),p=e.i(71952),h=e.i(59300),x=e.i(85005),R=e.i(69628),v=e.i(3185),y=e.i(47811),g=e.i(93695);e.i(635);var f=e.i(28214),w=e.i(14353),m=t([w]);[w]=m.then?(await m)():m;let b=new n.AppRouteRouteModule({definition:{kind:a.RouteKind.APP_ROUTE,page:"/api/v1/tools/selection/route",pathname:"/api/v1/tools/selection",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/src/app/api/v1/tools/selection/route.ts",nextConfigOutput:"standalone",userland:w}),{workAsyncStorage:S,workUnitAsyncStorage:T,serverHooks:A}=b;function C(){return(0,o.patchFetch)({workAsyncStorage:S,workUnitAsyncStorage:T})}async function E(e,t,r){b.isDev&&(0,s.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let n="/api/v1/tools/selection/route";n=n.replace(/\/index$/,"")||"/";let o=await b.prepare(e,t,{srcPage:n,multiZoneDraftMode:!1});if(!o)return t.statusCode=400,t.end("Bad Request"),null==r.waitUntil||r.waitUntil.call(r,Promise.resolve()),null;let{buildId:w,params:m,nextConfig:C,parsedUrl:E,isDraftMode:S,prerenderManifest:T,routerServerContext:A,isOnDemandRevalidate:N,revalidateOnlyGenerated:O,resolvedPathname:P,clientReferenceManifest:k,serverActionsManifest:q}=o,$=(0,d.normalizeAppPath)(n),H=!!(T.dynamicRoutes[$]||T.routes[P]),_=async()=>((null==A?void 0:A.render404)?await A.render404(e,t,E,!1):t.end("This page could not be found"),null);if(H&&!S){let e=!!T.routes[P],t=T.dynamicRoutes[$];if(t&&!1===t.fallback&&!e){if(C.experimental.adapterPath)return await _();throw new g.NoFallbackError}}let j=null;!H||b.isDev||S||(j=P,j="/index"===j?"/":j);let I=!0===b.isDev||!H,U=H&&!I;q&&k&&(0,l.setManifestsSingleton)({page:n,clientReferenceManifest:k,serverActionsManifest:q});let M=e.method||"GET",D=(0,i.getTracer)(),F=D.getActiveScopeSpan(),K={params:m,prerenderManifest:T,renderOpts:{experimental:{authInterrupts:!!C.experimental.authInterrupts},cacheComponents:!!C.cacheComponents,supportsDynamicResponse:I,incrementalCache:(0,s.getRequestMeta)(e,"incrementalCache"),cacheLifeProfiles:C.cacheLife,waitUntil:r.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,r,n,a)=>b.onRequestError(e,t,n,a,A)},sharedContext:{buildId:w}},L=new c.NodeNextRequest(e),B=new c.NodeNextResponse(t),J=u.NextRequestAdapter.fromNodeNextRequest(L,(0,u.signalFromNodeResponse)(t));try{let o=async e=>b.handle(J,K).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let r=D.getRootSpanAttributes();if(!r)return;if(r.get("next.span_type")!==p.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${r.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let a=r.get("next.route");if(a){let t=`${M} ${a}`;e.setAttributes({"next.route":a,"http.route":a,"next.span_name":t}),e.updateName(t)}else e.updateName(`${M} ${n}`)}),l=!!(0,s.getRequestMeta)(e,"minimalMode"),d=async s=>{var i,d;let c=async({previousCacheEntry:a})=>{try{if(!l&&N&&O&&!a)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let n=await o(s);e.fetchMetrics=K.renderOpts.fetchMetrics;let i=K.renderOpts.pendingWaitUntil;i&&r.waitUntil&&(r.waitUntil(i),i=void 0);let d=K.renderOpts.collectedTags;if(!H)return await (0,x.sendResponse)(L,B,n,K.renderOpts.pendingWaitUntil),null;{let e=await n.blob(),t=(0,R.toNodeOutgoingHttpHeaders)(n.headers);d&&(t[y.NEXT_CACHE_TAGS_HEADER]=d),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let r=void 0!==K.renderOpts.collectedRevalidate&&!(K.renderOpts.collectedRevalidate>=y.INFINITE_CACHE)&&K.renderOpts.collectedRevalidate,a=void 0===K.renderOpts.collectedExpire||K.renderOpts.collectedExpire>=y.INFINITE_CACHE?void 0:K.renderOpts.collectedExpire;return{value:{kind:f.CachedRouteKind.APP_ROUTE,status:n.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:r,expire:a}}}}catch(t){throw(null==a?void 0:a.isStale)&&await b.onRequestError(e,t,{routerKind:"App Router",routePath:n,routeType:"route",revalidateReason:(0,h.getRevalidateReason)({isStaticGeneration:U,isOnDemandRevalidate:N})},!1,A),t}},u=await b.handleResponse({req:e,nextConfig:C,cacheKey:j,routeKind:a.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:T,isRoutePPREnabled:!1,isOnDemandRevalidate:N,revalidateOnlyGenerated:O,responseGenerator:c,waitUntil:r.waitUntil,isMinimalMode:l});if(!H)return null;if((null==u||null==(i=u.value)?void 0:i.kind)!==f.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==u||null==(d=u.value)?void 0:d.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});l||t.setHeader("x-nextjs-cache",N?"REVALIDATED":u.isMiss?"MISS":u.isStale?"STALE":"HIT"),S&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let p=(0,R.fromNodeOutgoingHttpHeaders)(u.value.headers);return l&&H||p.delete(y.NEXT_CACHE_TAGS_HEADER),!u.cacheControl||t.getHeader("Cache-Control")||p.get("Cache-Control")||p.set("Cache-Control",(0,v.getCacheControlHeader)(u.cacheControl)),await (0,x.sendResponse)(L,B,new Response(u.value.body,{headers:p,status:u.value.status||200})),null};F?await d(F):await D.withPropagatedContext(e.headers,()=>D.trace(p.BaseServerSpan.handleRequest,{spanName:`${M} ${n}`,kind:i.SpanKind.SERVER,attributes:{"http.method":M,"http.target":e.url}},d))}catch(t){if(t instanceof g.NoFallbackError||await b.onRequestError(e,t,{routerKind:"App Router",routePath:$,routeType:"route",revalidateReason:(0,h.getRevalidateReason)({isStaticGeneration:U,isOnDemandRevalidate:N})},!1,A),H)throw t;return await (0,x.sendResponse)(L,B,new Response(null,{status:500})),null}}e.s(["handler",()=>E,"patchFetch",()=>C,"routeModule",()=>b,"serverHooks",()=>A,"workAsyncStorage",()=>S,"workUnitAsyncStorage",()=>T]),r()}catch(e){r(e)}},!1)];

//# sourceMappingURL=%5Broot-of-the-server%5D__71c536c5._.js.map