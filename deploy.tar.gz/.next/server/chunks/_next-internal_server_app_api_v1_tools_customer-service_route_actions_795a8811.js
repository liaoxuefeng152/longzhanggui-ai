module.exports=[2092,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_tools_customer-service_route_actions_795a8811.js.map