module.exports=[18622,(e,t,n)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,t,n)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,t,n)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},70406,(e,t,n)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},93695,(e,t,n)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},16494,e=>e.a(async(t,n)=>{try{let t=await e.y("coze-coding-dev-sdk-e40545b728faa7b1");e.n(t),n()}catch(e){n(e)}},!0),58461,e=>e.a(async(t,n)=>{try{var r=e.i(16494),a=t([r]);[r]=a.then?(await a)():a;let o={en:{name:"English",systemPrompt:"Generate listing in English"},th:{name:"Thai",systemPrompt:"生成泰语Listing，使用自然的泰语表达"},vi:{name:"Vietnamese",systemPrompt:"生成越南语Listing，使用自然的越南语表达"},ms:{name:"Malay",systemPrompt:"生成马来语Listing，使用自然的马来语表达"},id:{name:"Indonesian",systemPrompt:"生成印尼语Listing，使用自然的印尼语表达"},ph:{name:"Filipino",systemPrompt:"生成菲律宾语Listing，使用自然的菲律宾语表达"}},i=`你是跨境电商Listing优化专家，精通各大平台（Shopee、Lazada、TikTok Shop、Amazon）的Listing优化规则。

## 输出格式

### 1. 标题（Title）
- 长度：根据平台限制（一般100-150字符）
- 结构：品牌词 + 核心关键词 + 属性词 + 场景词
- 要求：包含主要关键词，语句通顺，吸引点击

### 2. 五点描述（Bullet Points）
- 每点50-100字符
- 突出卖点：功能、优势、使用场景、品质保证
- 使用简洁有力的表达

### 3. 详细描述（Description）
- 200-500字符
- 结构：产品介绍 → 核心卖点 → 使用场景 → 规格参数 → 购买须知
- 增强信任感和购买欲望

### 4. SEO关键词
- 核心关键词（3-5个）
- 长尾关键词（5-10个）
- 搜索热度建议

## 优化原则
1. 关键词自然融入，避免堆砌
2. 突出产品差异化卖点
3. 符合目标市场消费者习惯
4. 遵守平台规则，避免违禁词`;async function s(e){try{let{productName:t,category:n,features:a,targetMarket:s,targetLanguage:l,keywords:d,competitorTitles:p,tone:u="professional"}=await e.json();if(!t)return new Response(JSON.stringify({success:!1,error:"请提供产品名称"}),{status:400,headers:{"Content-Type":"application/json"}});let c=o[l]||o.en,h=`
请为以下产品生成Listing：

**产品名称**: ${t}
${n?`**类目**: ${n}`:""}
${a?.length?`**产品特点**:
${a.map(e=>`- ${e}`).join("\n")}`:""}
${d?.length?`**目标关键词**: ${d.join(", ")}`:""}
${p?.length?`**竞品标题参考**:
${p.map(e=>`- ${e}`).join("\n")}`:""}
**目标市场**: ${s}
**语气风格**: ${"professional"===u?"专业正式":"casual"===u?"轻松自然":"热情活泼"}

${c.systemPrompt}

请按以下格式输出：
## 📝 标题
[生成的标题]

## 📌 五点描述
1. [第一点]
2. [第二点]
3. [第三点]
4. [第四点]
5. [第五点]

## 📄 详细描述
[详细描述内容]

## 🔍 SEO关键词建议
- 核心关键词：[关键词列表]
- 长尾关键词：[关键词列表]

## 💡 优化建议
[针对该产品的Listing优化建议]
`,g=r.HeaderUtils.extractForwardHeaders(e.headers),m=new r.Config,y=new r.LLMClient(m,g),x=new TextEncoder,R=new ReadableStream({async start(e){try{e.enqueue(x.encode(`data: ${JSON.stringify({type:"start",message:`开始生成${c.name} Listing...`})}

`));let t=y.stream([{role:"system",content:i},{role:"user",content:h}],{model:"doubao-seed-1-8-251228",temperature:.7}),n="";for await(let r of t)if(r.content){let t=r.content.toString();n+=t,e.enqueue(x.encode(`data: ${JSON.stringify({type:"content",content:t})}

`))}e.enqueue(x.encode(`data: ${JSON.stringify({type:"done",fullResponse:n})}

`)),e.close()}catch(t){console.error("Listing generation error:",t),e.enqueue(x.encode(`data: ${JSON.stringify({type:"error",message:"生成失败，请重试"})}

`)),e.close()}}});return new Response(R,{headers:{"Content-Type":"text/event-stream","Cache-Control":"no-cache",Connection:"keep-alive"}})}catch(e){return console.error("Listing API error:",e),new Response(JSON.stringify({success:!1,error:"服务器内部错误"}),{status:500,headers:{"Content-Type":"application/json"}})}}e.s(["POST",()=>s]),n()}catch(e){n(e)}},!1),55405,e=>e.a(async(t,n)=>{try{var r=e.i(2710),a=e.i(35147),s=e.i(55688),o=e.i(87453),i=e.i(3771),l=e.i(47937),d=e.i(5457),p=e.i(17598),u=e.i(41045),c=e.i(71952),h=e.i(59300),g=e.i(85005),m=e.i(69628),y=e.i(3185),x=e.i(47811),R=e.i(93695);e.i(635);var v=e.i(28214),f=e.i(58461),w=t([f]);[f]=w.then?(await w)():w;let P=new r.AppRouteRouteModule({definition:{kind:a.RouteKind.APP_ROUTE,page:"/api/v1/tools/listing/route",pathname:"/api/v1/tools/listing",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/src/app/api/v1/tools/listing/route.ts",nextConfigOutput:"standalone",userland:f}),{workAsyncStorage:T,workUnitAsyncStorage:S,serverHooks:b}=P;function E(){return(0,s.patchFetch)({workAsyncStorage:T,workUnitAsyncStorage:S})}async function C(e,t,n){P.isDev&&(0,o.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let r="/api/v1/tools/listing/route";r=r.replace(/\/index$/,"")||"/";let s=await P.prepare(e,t,{srcPage:r,multiZoneDraftMode:!1});if(!s)return t.statusCode=400,t.end("Bad Request"),null==n.waitUntil||n.waitUntil.call(n,Promise.resolve()),null;let{buildId:f,params:w,nextConfig:E,parsedUrl:C,isDraftMode:T,prerenderManifest:S,routerServerContext:b,isOnDemandRevalidate:A,revalidateOnlyGenerated:O,resolvedPathname:N,clientReferenceManifest:$,serverActionsManifest:k}=s,q=(0,d.normalizeAppPath)(r),j=!!(S.dynamicRoutes[q]||S.routes[N]),L=async()=>((null==b?void 0:b.render404)?await b.render404(e,t,C,!1):t.end("This page could not be found"),null);if(j&&!T){let e=!!S.routes[N],t=S.dynamicRoutes[q];if(t&&!1===t.fallback&&!e){if(E.experimental.adapterPath)return await L();throw new R.NoFallbackError}}let _=null;!j||P.isDev||T||(_=N,_="/index"===_?"/":_);let H=!0===P.isDev||!j,I=j&&!H;k&&$&&(0,l.setManifestsSingleton)({page:r,clientReferenceManifest:$,serverActionsManifest:k});let U=e.method||"GET",D=(0,i.getTracer)(),M=D.getActiveScopeSpan(),F={params:w,prerenderManifest:S,renderOpts:{experimental:{authInterrupts:!!E.experimental.authInterrupts},cacheComponents:!!E.cacheComponents,supportsDynamicResponse:H,incrementalCache:(0,o.getRequestMeta)(e,"incrementalCache"),cacheLifeProfiles:E.cacheLife,waitUntil:n.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,n,r,a)=>P.onRequestError(e,t,r,a,b)},sharedContext:{buildId:f}},K=new p.NodeNextRequest(e),B=new p.NodeNextResponse(t),J=u.NextRequestAdapter.fromNodeNextRequest(K,(0,u.signalFromNodeResponse)(t));try{let s=async e=>P.handle(J,F).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let n=D.getRootSpanAttributes();if(!n)return;if(n.get("next.span_type")!==c.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${n.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let a=n.get("next.route");if(a){let t=`${U} ${a}`;e.setAttributes({"next.route":a,"http.route":a,"next.span_name":t}),e.updateName(t)}else e.updateName(`${U} ${r}`)}),l=!!(0,o.getRequestMeta)(e,"minimalMode"),d=async o=>{var i,d;let p=async({previousCacheEntry:a})=>{try{if(!l&&A&&O&&!a)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let r=await s(o);e.fetchMetrics=F.renderOpts.fetchMetrics;let i=F.renderOpts.pendingWaitUntil;i&&n.waitUntil&&(n.waitUntil(i),i=void 0);let d=F.renderOpts.collectedTags;if(!j)return await (0,g.sendResponse)(K,B,r,F.renderOpts.pendingWaitUntil),null;{let e=await r.blob(),t=(0,m.toNodeOutgoingHttpHeaders)(r.headers);d&&(t[x.NEXT_CACHE_TAGS_HEADER]=d),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let n=void 0!==F.renderOpts.collectedRevalidate&&!(F.renderOpts.collectedRevalidate>=x.INFINITE_CACHE)&&F.renderOpts.collectedRevalidate,a=void 0===F.renderOpts.collectedExpire||F.renderOpts.collectedExpire>=x.INFINITE_CACHE?void 0:F.renderOpts.collectedExpire;return{value:{kind:v.CachedRouteKind.APP_ROUTE,status:r.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:n,expire:a}}}}catch(t){throw(null==a?void 0:a.isStale)&&await P.onRequestError(e,t,{routerKind:"App Router",routePath:r,routeType:"route",revalidateReason:(0,h.getRevalidateReason)({isStaticGeneration:I,isOnDemandRevalidate:A})},!1,b),t}},u=await P.handleResponse({req:e,nextConfig:E,cacheKey:_,routeKind:a.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:S,isRoutePPREnabled:!1,isOnDemandRevalidate:A,revalidateOnlyGenerated:O,responseGenerator:p,waitUntil:n.waitUntil,isMinimalMode:l});if(!j)return null;if((null==u||null==(i=u.value)?void 0:i.kind)!==v.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==u||null==(d=u.value)?void 0:d.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});l||t.setHeader("x-nextjs-cache",A?"REVALIDATED":u.isMiss?"MISS":u.isStale?"STALE":"HIT"),T&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let c=(0,m.fromNodeOutgoingHttpHeaders)(u.value.headers);return l&&j||c.delete(x.NEXT_CACHE_TAGS_HEADER),!u.cacheControl||t.getHeader("Cache-Control")||c.get("Cache-Control")||c.set("Cache-Control",(0,y.getCacheControlHeader)(u.cacheControl)),await (0,g.sendResponse)(K,B,new Response(u.value.body,{headers:c,status:u.value.status||200})),null};M?await d(M):await D.withPropagatedContext(e.headers,()=>D.trace(c.BaseServerSpan.handleRequest,{spanName:`${U} ${r}`,kind:i.SpanKind.SERVER,attributes:{"http.method":U,"http.target":e.url}},d))}catch(t){if(t instanceof R.NoFallbackError||await P.onRequestError(e,t,{routerKind:"App Router",routePath:q,routeType:"route",revalidateReason:(0,h.getRevalidateReason)({isStaticGeneration:I,isOnDemandRevalidate:A})},!1,b),j)throw t;return await (0,g.sendResponse)(K,B,new Response(null,{status:500})),null}}e.s(["handler",()=>C,"patchFetch",()=>E,"routeModule",()=>P,"serverHooks",()=>b,"workAsyncStorage",()=>T,"workUnitAsyncStorage",()=>S]),n()}catch(e){n(e)}},!1)];

//# sourceMappingURL=%5Broot-of-the-server%5D__926b13be._.js.map