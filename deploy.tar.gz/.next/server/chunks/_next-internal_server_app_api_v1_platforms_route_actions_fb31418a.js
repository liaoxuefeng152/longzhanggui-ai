module.exports=[52360,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_platforms_route_actions_fb31418a.js.map