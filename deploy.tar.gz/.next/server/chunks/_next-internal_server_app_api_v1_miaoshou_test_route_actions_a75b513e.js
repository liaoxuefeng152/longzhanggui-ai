module.exports=[25165,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_miaoshou_test_route_actions_a75b513e.js.map