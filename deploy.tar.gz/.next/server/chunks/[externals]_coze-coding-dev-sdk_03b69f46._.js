module.exports=[16494,a=>a.a(async(e,c)=>{try{let e=await a.y("coze-coding-dev-sdk-e40545b728faa7b1");a.n(e),c()}catch(a){c(a)}},!0)];

//# sourceMappingURL=%5Bexternals%5D_coze-coding-dev-sdk_03b69f46._.js.map