module.exports=[8704,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_tools_data-review_route_actions_bcb4363c.js.map