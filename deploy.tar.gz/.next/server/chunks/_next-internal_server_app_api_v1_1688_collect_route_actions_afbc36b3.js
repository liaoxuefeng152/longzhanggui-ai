module.exports=[68793,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_1688_collect_route_actions_afbc36b3.js.map