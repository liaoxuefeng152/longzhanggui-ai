module.exports=[18622,(e,t,r)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},24725,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},70406,(e,t,r)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},93695,(e,t,r)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},9790,e=>{"use strict";var t=e.i(2710),r=e.i(35147),a=e.i(55688),n=e.i(87453),s=e.i(3771),i=e.i(47937),o=e.i(5457),l=e.i(17598),d=e.i(41045),u=e.i(71952),p=e.i(59300),c=e.i(85005),h=e.i(69628),x=e.i(3185),R=e.i(47811),v=e.i(93695);e.i(635);var f=e.i(28214),g=e.i(78869);async function m(e){try{let{message:t}=await e.json();if(!t)return g.NextResponse.json({detail:"消息不能为空"},{status:400});let r=t.toLowerCase(),a="";return a=r.includes("选品")||r.includes("选")||r.includes("产品")?`针对您的选品需求，我为您推荐以下建议：

### 🔍 选品分析

基于您的需求，我建议关注以下几个方向：

1. **便携式充电设备** - TikTok东南亚市场热门，体积小、物流成本低
2. **手机配件** - 泰国、越南市场需求旺盛，利润空间可观
3. **家居小物件** - 创意类产品容易在短视频平台爆火

### 📊 建议操作
- 点击右侧「选品SKILL」获取详细分析
- 查看「商品库」了解已有选品
- 使用「竞品分析」功能深入研究

如需更详细的分析，请提供：
- 目标站点（泰国/越南/马来西亚等）
- 预算范围
- 擅长类目`:r.includes("库存")||r.includes("补货")?`📦 **库存查询**

目前系统支持以下库存相关功能：

1. **库存总览** - 查看所有商品库存状态
2. **库存预警** - 低库存自动提醒
3. **补货建议** - 基于销售数据的智能补货

请前往「ERP系统 > 库存管理」查看详细信息。`:r.includes("订单")||r.includes("发货")?`📋 **订单管理**

您可以在「ERP系统 > 订单中心」进行以下操作：

- 查看所有订单状态
- 处理待发货订单
- 追踪物流信息
- 处理售后问题`:r.includes("帮助")||r.includes("怎么用")?`🦞 **龙掌柜AI助手使用指南**

我是您的智能运营助理，可以帮助您：

| 功能 | 说明 |
|------|------|
| 🔍 选品分析 | 市场趋势、竞品分析、蓝海类目 |
| 📸 素材制作 | 图片/视频建议、Listing优化 |
| 💰 定价计算 | 成本核算、利润分析 |
| 📊 数据分析 | 运营日报、周报、数据复盘 |

直接告诉我您的需求，我会尽力帮助您！`:`您好！我是龙掌柜AI运营助手 🦞

我可以帮助您处理跨境电商运营相关的各种问题：

- **选品分析** - 市场趋势、竞品研究
- **库存查询** - 库存状态、补货建议  
- **订单管理** - 订单处理、物流追踪
- **数据分析** - 运营报表、销售数据

请告诉我您需要什么帮助？`,g.NextResponse.json({content:a,model:"assistant"})}catch(e){return console.error("AI chat error:",e),g.NextResponse.json({detail:"AI服务暂时不可用"},{status:500})}}e.s(["POST",()=>m],58180);var E=e.i(58180);let w=new t.AppRouteRouteModule({definition:{kind:r.RouteKind.APP_ROUTE,page:"/api/v1/ai/chat/route",pathname:"/api/v1/ai/chat",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/src/app/api/v1/ai/chat/route.ts",nextConfigOutput:"standalone",userland:E}),{workAsyncStorage:y,workUnitAsyncStorage:C,serverHooks:A}=w;function b(){return(0,a.patchFetch)({workAsyncStorage:y,workUnitAsyncStorage:C})}async function T(e,t,a){w.isDev&&(0,n.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let g="/api/v1/ai/chat/route";g=g.replace(/\/index$/,"")||"/";let m=await w.prepare(e,t,{srcPage:g,multiZoneDraftMode:!1});if(!m)return t.statusCode=400,t.end("Bad Request"),null==a.waitUntil||a.waitUntil.call(a,Promise.resolve()),null;let{buildId:E,params:y,nextConfig:C,parsedUrl:A,isDraftMode:b,prerenderManifest:T,routerServerContext:N,isOnDemandRevalidate:P,revalidateOnlyGenerated:k,resolvedPathname:O,clientReferenceManifest:j,serverActionsManifest:S}=m,q=(0,o.normalizeAppPath)(g),I=!!(T.dynamicRoutes[q]||T.routes[O]),_=async()=>((null==N?void 0:N.render404)?await N.render404(e,t,A,!1):t.end("This page could not be found"),null);if(I&&!b){let e=!!T.routes[O],t=T.dynamicRoutes[q];if(t&&!1===t.fallback&&!e){if(C.experimental.adapterPath)return await _();throw new v.NoFallbackError}}let H=null;!I||w.isDev||b||(H="/index"===(H=O)?"/":H);let U=!0===w.isDev||!I,D=I&&!U;S&&j&&(0,i.setManifestsSingleton)({page:g,clientReferenceManifest:j,serverActionsManifest:S});let M=e.method||"GET",K=(0,s.getTracer)(),L=K.getActiveScopeSpan(),$={params:y,prerenderManifest:T,renderOpts:{experimental:{authInterrupts:!!C.experimental.authInterrupts},cacheComponents:!!C.cacheComponents,supportsDynamicResponse:U,incrementalCache:(0,n.getRequestMeta)(e,"incrementalCache"),cacheLifeProfiles:C.cacheLife,waitUntil:a.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,r,a,n)=>w.onRequestError(e,t,a,n,N)},sharedContext:{buildId:E}},F=new l.NodeNextRequest(e),B=new l.NodeNextResponse(t),G=d.NextRequestAdapter.fromNodeNextRequest(F,(0,d.signalFromNodeResponse)(t));try{let i=async e=>w.handle(G,$).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let r=K.getRootSpanAttributes();if(!r)return;if(r.get("next.span_type")!==u.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${r.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let a=r.get("next.route");if(a){let t=`${M} ${a}`;e.setAttributes({"next.route":a,"http.route":a,"next.span_name":t}),e.updateName(t)}else e.updateName(`${M} ${g}`)}),o=!!(0,n.getRequestMeta)(e,"minimalMode"),l=async n=>{var s,l;let d=async({previousCacheEntry:r})=>{try{if(!o&&P&&k&&!r)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let s=await i(n);e.fetchMetrics=$.renderOpts.fetchMetrics;let l=$.renderOpts.pendingWaitUntil;l&&a.waitUntil&&(a.waitUntil(l),l=void 0);let d=$.renderOpts.collectedTags;if(!I)return await (0,c.sendResponse)(F,B,s,$.renderOpts.pendingWaitUntil),null;{let e=await s.blob(),t=(0,h.toNodeOutgoingHttpHeaders)(s.headers);d&&(t[R.NEXT_CACHE_TAGS_HEADER]=d),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let r=void 0!==$.renderOpts.collectedRevalidate&&!($.renderOpts.collectedRevalidate>=R.INFINITE_CACHE)&&$.renderOpts.collectedRevalidate,a=void 0===$.renderOpts.collectedExpire||$.renderOpts.collectedExpire>=R.INFINITE_CACHE?void 0:$.renderOpts.collectedExpire;return{value:{kind:f.CachedRouteKind.APP_ROUTE,status:s.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:r,expire:a}}}}catch(t){throw(null==r?void 0:r.isStale)&&await w.onRequestError(e,t,{routerKind:"App Router",routePath:g,routeType:"route",revalidateReason:(0,p.getRevalidateReason)({isStaticGeneration:D,isOnDemandRevalidate:P})},!1,N),t}},u=await w.handleResponse({req:e,nextConfig:C,cacheKey:H,routeKind:r.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:T,isRoutePPREnabled:!1,isOnDemandRevalidate:P,revalidateOnlyGenerated:k,responseGenerator:d,waitUntil:a.waitUntil,isMinimalMode:o});if(!I)return null;if((null==u||null==(s=u.value)?void 0:s.kind)!==f.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==u||null==(l=u.value)?void 0:l.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});o||t.setHeader("x-nextjs-cache",P?"REVALIDATED":u.isMiss?"MISS":u.isStale?"STALE":"HIT"),b&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let v=(0,h.fromNodeOutgoingHttpHeaders)(u.value.headers);return o&&I||v.delete(R.NEXT_CACHE_TAGS_HEADER),!u.cacheControl||t.getHeader("Cache-Control")||v.get("Cache-Control")||v.set("Cache-Control",(0,x.getCacheControlHeader)(u.cacheControl)),await (0,c.sendResponse)(F,B,new Response(u.value.body,{headers:v,status:u.value.status||200})),null};L?await l(L):await K.withPropagatedContext(e.headers,()=>K.trace(u.BaseServerSpan.handleRequest,{spanName:`${M} ${g}`,kind:s.SpanKind.SERVER,attributes:{"http.method":M,"http.target":e.url}},l))}catch(t){if(t instanceof v.NoFallbackError||await w.onRequestError(e,t,{routerKind:"App Router",routePath:q,routeType:"route",revalidateReason:(0,p.getRevalidateReason)({isStaticGeneration:D,isOnDemandRevalidate:P})},!1,N),I)throw t;return await (0,c.sendResponse)(F,B,new Response(null,{status:500})),null}}e.s(["handler",()=>T,"patchFetch",()=>b,"routeModule",()=>w,"serverHooks",()=>A,"workAsyncStorage",()=>y,"workUnitAsyncStorage",()=>C],9790)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__65f1f160._.js.map