module.exports=[68869,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_ai_process-image_route_actions_8df785db.js.map