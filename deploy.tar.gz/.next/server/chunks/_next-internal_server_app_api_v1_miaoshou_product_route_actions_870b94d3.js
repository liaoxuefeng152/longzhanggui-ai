module.exports=[13842,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_miaoshou_product_route_actions_870b94d3.js.map