module.exports=[70406,(e,t,r)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},93695,(e,t,r)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},18622,(e,t,r)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},24725,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},14747,(e,t,r)=>{t.exports=e.x("path",()=>require("path"))},94824,(e,t,r)=>{t.exports=e.x("better-sqlite3-6af3159004069310",()=>require("better-sqlite3-6af3159004069310"))},22734,(e,t,r)=>{t.exports=e.x("fs",()=>require("fs"))},84501,e=>{"use strict";var t=e.i(94824),r=e.i(14747),a=e.i(22734);let n=r.default.join(process.cwd(),"data","lobster.db"),s=r.default.dirname(n);a.default.existsSync(s)||a.default.mkdirSync(s,{recursive:!0});let i=null;function o(){return i||((i=new t.default(n)).pragma("journal_mode = WAL"),i.pragma("foreign_keys = ON"),function(e){e.exec(`
    CREATE TABLE IF NOT EXISTS platforms (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      platform TEXT NOT NULL,
      credentials TEXT DEFAULT '{}',
      status TEXT DEFAULT 'disconnected',
      last_sync TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    )
  `),e.exec(`
    CREATE TABLE IF NOT EXISTS miaoshou_config (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      phone TEXT NOT NULL,
      password TEXT NOT NULL,
      cookies TEXT,
      status TEXT DEFAULT 'disconnected',
      last_sync TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    )
  `);try{e.exec("ALTER TABLE miaoshou_config ADD COLUMN app_key TEXT"),e.exec("ALTER TABLE miaoshou_config ADD COLUMN app_secret TEXT")}catch(e){}e.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      username TEXT NOT NULL UNIQUE,
      password TEXT NOT NULL,
      email TEXT,
      role TEXT DEFAULT 'client',
      avatar TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    )
  `),e.exec(`
    CREATE TABLE IF NOT EXISTS products (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      name_en TEXT,
      sku TEXT,
      category TEXT,
      cost_price REAL DEFAULT 0,
      price REAL DEFAULT 0,
      stock INTEGER DEFAULT 0,
      status TEXT DEFAULT 'draft',
      source TEXT,
      source_url TEXT,
      supplier_name TEXT,
      supplier_id TEXT,
      images TEXT DEFAULT '[]',
      video_url TEXT,
      weight REAL,
      dimensions TEXT,
      description TEXT,
      description_en TEXT,
      keywords TEXT,
      attributes TEXT DEFAULT '{}',
      shop_id TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    )
  `),e.exec(`
    CREATE TABLE IF NOT EXISTS collection_products (
      id TEXT PRIMARY KEY,
      collection_id TEXT,
      product_id TEXT,
      product_name TEXT NOT NULL,
      source TEXT,
      source_url TEXT,
      source_id TEXT,
      supplier_name TEXT,
      cost_price REAL DEFAULT 0,
      images TEXT DEFAULT '[]',
      category TEXT,
      claimed INTEGER DEFAULT 0,
      claimed_by TEXT,
      claimed_at TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    )
  `),e.exec(`
    CREATE TABLE IF NOT EXISTS feishu_config (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      app_id TEXT NOT NULL,
      app_secret TEXT NOT NULL,
      bot_name TEXT,
      webhook_url TEXT,
      push_enabled INTEGER DEFAULT 0,
      alert_enabled INTEGER DEFAULT 1,
      alert_threshold INTEGER DEFAULT 10,
      templates TEXT DEFAULT '{}',
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    )
  `),e.exec(`
    CREATE TABLE IF NOT EXISTS import_history (
      id TEXT PRIMARY KEY,
      type TEXT NOT NULL,
      file_name TEXT,
      status TEXT DEFAULT 'pending',
      total_rows INTEGER DEFAULT 0,
      success_rows INTEGER DEFAULT 0,
      error_rows INTEGER DEFAULT 0,
      error_log TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      completed_at TEXT
    )
  `),0===e.prepare("SELECT COUNT(*) as count FROM users WHERE role = ?").get("admin").count&&e.prepare(`
      INSERT INTO users (id, username, password, email, role) VALUES (?, ?, ?, ?, ?)
    `).run("admin","admin","admin123","admin@example.com","admin"),0===e.prepare("SELECT COUNT(*) as count FROM feishu_config").get().count&&e.prepare(`
      INSERT INTO feishu_config (app_id, app_secret, bot_name, push_enabled, alert_enabled)
      VALUES (?, ?, ?, ?, ?)
    `).run("","","龙掌柜跨境AI全能助手",0,1),console.log("[DB] Database tables initialized")}(i)),i}e.s(["getDb",()=>o])},54799,(e,t,r)=>{t.exports=e.x("crypto",()=>require("crypto"))},60694,e=>{"use strict";var t=e.i(2710),r=e.i(35147),a=e.i(55688),n=e.i(87453),s=e.i(3771),i=e.i(47937),o=e.i(5457),d=e.i(17598),l=e.i(41045),c=e.i(71952),T=e.i(59300),u=e.i(85005),p=e.i(69628),E=e.i(3185),m=e.i(47811),R=e.i(93695);e.i(635);var h=e.i(28214),_=e.i(78869),g=e.i(84501);e.i(54799);let A="https://open.feishu.cn/open-apis";async function L(e,t){try{let r=await fetch(`${A}/auth/v3/tenant_access_token/internal`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({app_id:e,app_secret:t})}),a=await r.json();if(0===a.code)return a.tenant_access_token;return console.error("获取tenant_access_token失败:",a),null}catch(e){return console.error("获取tenant_access_token异常:",e),null}}async function x(e,t,r,a,n){try{let s=await fetch(`${A}/im/v1/messages?receive_id_type=${t}`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${e}`},body:JSON.stringify({receive_id:r,msg_type:a,content:n})}),i=await s.json();return 0===i.code}catch(e){return console.error("发送消息失败:",e),!1}}async function f(e){try{let r=await e.text();e.headers;let a=(0,g.getDb)().prepare("SELECT * FROM feishu_config WHERE id = 1").get();if(!a||!a.app_id||!a.app_secret)return _.NextResponse.json({error:"飞书配置未完成"},{status:400});let n=JSON.parse(r);if(console.log("收到飞书事件:",JSON.stringify(n)),"url_verification"===n.type)return _.NextResponse.json({challenge:n.challenge});if(n.header?.event_type){let e=n.header.event_type,r=n.event,s=await L(a.app_id,a.app_secret);if(!s)return _.NextResponse.json({error:"获取access_token失败"},{status:500});if("im.message.receive_v1"===e){var t;let e,a,n=r.message,i=r.sender;if("p2p"!==n.chat_type)return _.NextResponse.json({code:0,msg:"群消息暂不支持"});if(i?.sender_type==="app")return _.NextResponse.json({code:0,msg:"忽略机器人消息"});let o="";"text"===n.message_type?o=JSON.parse(n.content).text:"post"===n.message_type&&(o="[用户发送了富文本/图片消息]"),console.log("收到用户消息:",o);let d=(e=o.toLowerCase()).includes("选品")||e.includes("爆款")||e.includes("热卖")?{intent:"product-selection",action:"跳转到选品SKILL",params:{}}:e.includes("图片")||e.includes("翻译")||e.includes("主图")?{intent:"image-design",action:"跳转到图片设计",params:{}}:e.includes("listing")||e.includes("标题")||e.includes("描述")?{intent:"listing",action:"跳转到Listing优化",params:{}}:e.includes("广告")||e.includes("roi")||e.includes("预算")?{intent:"advertising",action:"跳转到广告投放",params:{}}:e.includes("数据")||e.includes("日报")||e.includes("销量")?{intent:"data-query",action:"查看数据报表",params:{}}:e.includes("库存")||e.includes("补货")||e.includes("预警")?{intent:"inventory",action:"查看库存情况",params:{}}:e.includes("订单")||e.includes("物流")||e.includes("发货")?{intent:"orders",action:"查看订单列表",params:{}}:e.includes("客服")||e.includes("差评")||e.includes("回复")?{intent:"customer-service",action:"跳转到客服处理",params:{}}:{intent:"general",action:"智能回复",params:{}};console.log("识别意图:",d);let l=(t=d.intent,(a={"product-selection":`好的，我来帮你进行选品分析！

请告诉我：
1. **目标市场**：东南亚/欧美/拉美？
2. **类目偏好**：3C数码/家居/服装/美妆？
3. **预算范围**：每款产品的采购预算？
4. **核心诉求**：爆款/蓝海/差异化？

你可以直接告诉我你的需求，例如：
- "帮我选3款3C产品，主攻东南亚市场"
- "找一些家居类蓝海产品"

输入你的需求，我将调用选品SKILL为你分析！`,"image-design":`好的，我来帮你处理图片！

支持的图片处理功能：
1. **图片翻译**：将图片中的文字翻译成目标语言
2. **主图优化**：生成更吸引人的产品主图
3. **白底图**：将图片背景处理成白底

请直接发送图片并告诉我需要什么处理，例如：
- "翻译这张图片成英文"
- "帮我优化这个产品主图"

我将通过图片设计SKILL为你处理！`,listing:`好的，我来帮你优化Listing！

请提供商品信息，我可以帮你：
1. **标题优化**：提升搜索排名和点击率
2. **五点描述**：突出产品卖点
3. **关键词挖掘**：找到高流量关键词
4. **多语言翻译**：英语/泰语/越南语等

请告诉我：
- 商品链接或详细信息
- 需要优化的语言版本

我将调用Listing优化SKILL为你服务！`,advertising:`好的，我来帮你分析广告投放！

请告诉我：
1. **广告目标**：新品推广/爆款打造/清库存？
2. **目标平台**：TikTok/Amazon/Shopee？
3. **预算范围**：日预算多少？
4. **预期ROI**：想要达到几倍回报？

我可以帮你：
- 分析竞品广告策略
- 制定广告投放方案
- 监控ROI表现

请输入你的需求！`,"data-query":`好的，我来帮你查询数据！

支持的查询：
1. **销售数据**：今日/本周/本月销量
2. **TOP商品**：销量最高的产品
3. **利润分析**：各产品利润情况
4. **运营日报**：每日运营汇总

请告诉我你想要查询什么数据？`,inventory:`好的，我来帮你查看库存！

我可以帮你：
1. **库存预警**：低于安全库存的商品
2. **补货建议**：需要及时补货的产品
3. **库存分析**：库存周转情况

请告诉我你想要查看什么？`,orders:`好的，我来帮你处理订单！

支持的订单功能：
1. **订单查询**：查看订单状态和详情
2. **物流跟踪**：追踪包裹物流信息
3. **异常订单**：处理退款、退货、纠纷

请告诉我你的需求？`,"customer-service":`好的，我来帮你处理客服问题！

支持的客服功能：
1. **回复生成**：AI生成专业客服回复
2. **差评处理**：分析差评原因并给出解决方案
3. **纠纷处理**：帮助处理平台纠纷

请告诉我遇到了什么客服问题？`,general:`你好！我是龙掌柜跨境AI全能助手。

我可以帮你完成以下工作：

**AI SKILL能力：**
1. 📦 选品分析 - 帮你找到爆款产品
2. 🖼️ 图片设计 - 图片翻译、主图优化
3. 📝 Listing优化 - 标题、描述、关键词
4. 📊 广告投放 - ROI分析、投放策略
5. 💬 客服处理 - 回复生成、差评处理
6. 📈 数据复盘 - 销售分析、运营日报
7. 💰 智能定价 - 成本计算、利润优化

**你可以这样问我：**
- "帮我选3款3C产品"
- "翻译这张产品图片"
- "今天销量多少？"
- "帮我分析这个新品"

请告诉我你需要什么帮助！`})[t]||a.general);await x(s,"message_id",n.message_id,"text",JSON.stringify({text:l}))?console.log("回复发送成功"):console.error("回复发送失败")}}return _.NextResponse.json({code:0,msg:"success"})}catch(e){return console.error("处理飞书事件失败:",e),_.NextResponse.json({error:"处理失败"},{status:500})}}async function N(){return _.NextResponse.json({status:"ok",message:"飞书Webhook服务正常运行",time:new Date().toISOString()})}e.s(["GET",()=>N,"POST",()=>f],83985);var X=e.i(83985);let v=new t.AppRouteRouteModule({definition:{kind:r.RouteKind.APP_ROUTE,page:"/api/v1/feishu/webhook/route",pathname:"/api/v1/feishu/webhook",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/src/app/api/v1/feishu/webhook/route.ts",nextConfigOutput:"standalone",userland:X}),{workAsyncStorage:w,workUnitAsyncStorage:y,serverHooks:U}=v;function I(){return(0,a.patchFetch)({workAsyncStorage:w,workUnitAsyncStorage:y})}async function O(e,t,a){v.isDev&&(0,n.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let _="/api/v1/feishu/webhook/route";_=_.replace(/\/index$/,"")||"/";let g=await v.prepare(e,t,{srcPage:_,multiZoneDraftMode:!1});if(!g)return t.statusCode=400,t.end("Bad Request"),null==a.waitUntil||a.waitUntil.call(a,Promise.resolve()),null;let{buildId:A,params:L,nextConfig:x,parsedUrl:f,isDraftMode:N,prerenderManifest:X,routerServerContext:w,isOnDemandRevalidate:y,revalidateOnlyGenerated:U,resolvedPathname:I,clientReferenceManifest:O,serverActionsManifest:S}=g,C=(0,o.normalizeAppPath)(_),D=!!(X.dynamicRoutes[C]||X.routes[I]),F=async()=>((null==w?void 0:w.render404)?await w.render404(e,t,f,!1):t.end("This page could not be found"),null);if(D&&!N){let e=!!X.routes[I],t=X.dynamicRoutes[C];if(t&&!1===t.fallback&&!e){if(x.experimental.adapterPath)return await F();throw new R.NoFallbackError}}let b=null;!D||v.isDev||N||(b="/index"===(b=I)?"/":b);let k=!0===v.isDev||!D,P=D&&!k;S&&O&&(0,i.setManifestsSingleton)({page:_,clientReferenceManifest:O,serverActionsManifest:S});let j=e.method||"GET",q=(0,s.getTracer)(),M=q.getActiveScopeSpan(),K={params:L,prerenderManifest:X,renderOpts:{experimental:{authInterrupts:!!x.experimental.authInterrupts},cacheComponents:!!x.cacheComponents,supportsDynamicResponse:k,incrementalCache:(0,n.getRequestMeta)(e,"incrementalCache"),cacheLifeProfiles:x.cacheLife,waitUntil:a.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,r,a,n)=>v.onRequestError(e,t,a,n,w)},sharedContext:{buildId:A}},H=new d.NodeNextRequest(e),B=new d.NodeNextResponse(t),G=l.NextRequestAdapter.fromNodeNextRequest(H,(0,l.signalFromNodeResponse)(t));try{let i=async e=>v.handle(G,K).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let r=q.getRootSpanAttributes();if(!r)return;if(r.get("next.span_type")!==c.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${r.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let a=r.get("next.route");if(a){let t=`${j} ${a}`;e.setAttributes({"next.route":a,"http.route":a,"next.span_name":t}),e.updateName(t)}else e.updateName(`${j} ${_}`)}),o=!!(0,n.getRequestMeta)(e,"minimalMode"),d=async n=>{var s,d;let l=async({previousCacheEntry:r})=>{try{if(!o&&y&&U&&!r)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let s=await i(n);e.fetchMetrics=K.renderOpts.fetchMetrics;let d=K.renderOpts.pendingWaitUntil;d&&a.waitUntil&&(a.waitUntil(d),d=void 0);let l=K.renderOpts.collectedTags;if(!D)return await (0,u.sendResponse)(H,B,s,K.renderOpts.pendingWaitUntil),null;{let e=await s.blob(),t=(0,p.toNodeOutgoingHttpHeaders)(s.headers);l&&(t[m.NEXT_CACHE_TAGS_HEADER]=l),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let r=void 0!==K.renderOpts.collectedRevalidate&&!(K.renderOpts.collectedRevalidate>=m.INFINITE_CACHE)&&K.renderOpts.collectedRevalidate,a=void 0===K.renderOpts.collectedExpire||K.renderOpts.collectedExpire>=m.INFINITE_CACHE?void 0:K.renderOpts.collectedExpire;return{value:{kind:h.CachedRouteKind.APP_ROUTE,status:s.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:r,expire:a}}}}catch(t){throw(null==r?void 0:r.isStale)&&await v.onRequestError(e,t,{routerKind:"App Router",routePath:_,routeType:"route",revalidateReason:(0,T.getRevalidateReason)({isStaticGeneration:P,isOnDemandRevalidate:y})},!1,w),t}},c=await v.handleResponse({req:e,nextConfig:x,cacheKey:b,routeKind:r.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:X,isRoutePPREnabled:!1,isOnDemandRevalidate:y,revalidateOnlyGenerated:U,responseGenerator:l,waitUntil:a.waitUntil,isMinimalMode:o});if(!D)return null;if((null==c||null==(s=c.value)?void 0:s.kind)!==h.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==c||null==(d=c.value)?void 0:d.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});o||t.setHeader("x-nextjs-cache",y?"REVALIDATED":c.isMiss?"MISS":c.isStale?"STALE":"HIT"),N&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let R=(0,p.fromNodeOutgoingHttpHeaders)(c.value.headers);return o&&D||R.delete(m.NEXT_CACHE_TAGS_HEADER),!c.cacheControl||t.getHeader("Cache-Control")||R.get("Cache-Control")||R.set("Cache-Control",(0,E.getCacheControlHeader)(c.cacheControl)),await (0,u.sendResponse)(H,B,new Response(c.value.body,{headers:R,status:c.value.status||200})),null};M?await d(M):await q.withPropagatedContext(e.headers,()=>q.trace(c.BaseServerSpan.handleRequest,{spanName:`${j} ${_}`,kind:s.SpanKind.SERVER,attributes:{"http.method":j,"http.target":e.url}},d))}catch(t){if(t instanceof R.NoFallbackError||await v.onRequestError(e,t,{routerKind:"App Router",routePath:C,routeType:"route",revalidateReason:(0,T.getRevalidateReason)({isStaticGeneration:P,isOnDemandRevalidate:y})},!1,w),D)throw t;return await (0,u.sendResponse)(H,B,new Response(null,{status:500})),null}}e.s(["handler",()=>O,"patchFetch",()=>I,"routeModule",()=>v,"serverHooks",()=>U,"workAsyncStorage",()=>w,"workUnitAsyncStorage",()=>y],60694)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__3e773579._.js.map