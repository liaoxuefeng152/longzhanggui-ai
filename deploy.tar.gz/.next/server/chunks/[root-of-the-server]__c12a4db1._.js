module.exports=[70406,(e,t,r)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},93695,(e,t,r)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},18622,(e,t,r)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},24725,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},14747,(e,t,r)=>{t.exports=e.x("path",()=>require("path"))},54799,(e,t,r)=>{t.exports=e.x("crypto",()=>require("crypto"))},94824,(e,t,r)=>{t.exports=e.x("better-sqlite3-6af3159004069310",()=>require("better-sqlite3-6af3159004069310"))},22734,(e,t,r)=>{t.exports=e.x("fs",()=>require("fs"))},84501,e=>{"use strict";var t=e.i(94824),r=e.i(14747),a=e.i(22734);let o=r.default.join(process.cwd(),"data","lobster.db"),s=r.default.dirname(o);a.default.existsSync(s)||a.default.mkdirSync(s,{recursive:!0});let n=null;function i(){return n||((n=new t.default(o)).pragma("journal_mode = WAL"),n.pragma("foreign_keys = ON"),function(e){e.exec(`
    CREATE TABLE IF NOT EXISTS platforms (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      platform TEXT NOT NULL,
      credentials TEXT DEFAULT '{}',
      status TEXT DEFAULT 'disconnected',
      last_sync TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    )
  `),e.exec(`
    CREATE TABLE IF NOT EXISTS miaoshou_config (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      phone TEXT NOT NULL,
      password TEXT NOT NULL,
      cookies TEXT,
      status TEXT DEFAULT 'disconnected',
      last_sync TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    )
  `);try{e.exec("ALTER TABLE miaoshou_config ADD COLUMN app_key TEXT"),e.exec("ALTER TABLE miaoshou_config ADD COLUMN app_secret TEXT")}catch(e){}e.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      username TEXT NOT NULL UNIQUE,
      password TEXT NOT NULL,
      email TEXT,
      role TEXT DEFAULT 'client',
      avatar TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    )
  `),e.exec(`
    CREATE TABLE IF NOT EXISTS products (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      name_en TEXT,
      sku TEXT,
      category TEXT,
      cost_price REAL DEFAULT 0,
      price REAL DEFAULT 0,
      stock INTEGER DEFAULT 0,
      status TEXT DEFAULT 'draft',
      source TEXT,
      source_url TEXT,
      supplier_name TEXT,
      supplier_id TEXT,
      images TEXT DEFAULT '[]',
      video_url TEXT,
      weight REAL,
      dimensions TEXT,
      description TEXT,
      description_en TEXT,
      keywords TEXT,
      attributes TEXT DEFAULT '{}',
      shop_id TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    )
  `),e.exec(`
    CREATE TABLE IF NOT EXISTS collection_products (
      id TEXT PRIMARY KEY,
      collection_id TEXT,
      product_id TEXT,
      product_name TEXT NOT NULL,
      source TEXT,
      source_url TEXT,
      source_id TEXT,
      supplier_name TEXT,
      cost_price REAL DEFAULT 0,
      images TEXT DEFAULT '[]',
      category TEXT,
      claimed INTEGER DEFAULT 0,
      claimed_by TEXT,
      claimed_at TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    )
  `),e.exec(`
    CREATE TABLE IF NOT EXISTS feishu_config (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      app_id TEXT NOT NULL,
      app_secret TEXT NOT NULL,
      bot_name TEXT,
      webhook_url TEXT,
      push_enabled INTEGER DEFAULT 0,
      alert_enabled INTEGER DEFAULT 1,
      alert_threshold INTEGER DEFAULT 10,
      templates TEXT DEFAULT '{}',
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    )
  `),e.exec(`
    CREATE TABLE IF NOT EXISTS import_history (
      id TEXT PRIMARY KEY,
      type TEXT NOT NULL,
      file_name TEXT,
      status TEXT DEFAULT 'pending',
      total_rows INTEGER DEFAULT 0,
      success_rows INTEGER DEFAULT 0,
      error_rows INTEGER DEFAULT 0,
      error_log TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      completed_at TEXT
    )
  `),0===e.prepare("SELECT COUNT(*) as count FROM users WHERE role = ?").get("admin").count&&e.prepare(`
      INSERT INTO users (id, username, password, email, role) VALUES (?, ?, ?, ?, ?)
    `).run("admin","admin","admin123","admin@example.com","admin"),0===e.prepare("SELECT COUNT(*) as count FROM feishu_config").get().count&&e.prepare(`
      INSERT INTO feishu_config (app_id, app_secret, bot_name, push_enabled, alert_enabled)
      VALUES (?, ?, ?, ?, ?)
    `).run("","","龙掌柜跨境AI全能助手",0,1),console.log("[DB] Database tables initialized")}(n)),n}e.s(["getDb",()=>i])},42203,e=>{"use strict";var t=e.i(84501);e.s(["MiaoshouDAL",0,{get(){let e=(0,t.getDb)().prepare("SELECT * FROM miaoshou_config LIMIT 1").get();if(e)return{id:String(e.id),phone:e.phone,password:e.password,cookies:e.cookies,appKey:e.app_key,appSecret:e.app_secret,status:e.status,lastSync:e.last_sync,updated_at:e.updated_at}},save(e){let r=(0,t.getDb)();try{return r.prepare("DELETE FROM miaoshou_config").run(),r.prepare(`
        INSERT INTO miaoshou_config (phone, password, cookies, app_key, app_secret, status, updated_at)
        VALUES (?, ?, ?, ?, ?, 'disconnected', datetime('now'))
      `).run(e.phone,e.password,e.cookies||null,e.appKey||null,e.appSecret||null),!0}catch(e){return console.error("[DAL] Miaoshou save error:",e),!1}},updateStatus(e){let r=(0,t.getDb)();try{return r.prepare("UPDATE miaoshou_config SET status = ?, updated_at = datetime('now')").run(e),!0}catch(e){return console.error("[DAL] Miaoshou updateStatus error:",e),!1}},updateCookies(e){let r=(0,t.getDb)();try{return r.prepare("UPDATE miaoshou_config SET cookies = ?, updated_at = datetime('now')").run(e),!0}catch(e){return console.error("[DAL] Miaoshou updateCookies error:",e),!1}}},"PlatformDAL",0,{getAll:()=>(0,t.getDb)().prepare("SELECT * FROM platforms ORDER BY created_at DESC").all(),getById:e=>(0,t.getDb)().prepare("SELECT * FROM platforms WHERE id = ?").get(e),upsert(e){let r=(0,t.getDb)();try{return r.prepare(`
        INSERT INTO platforms (id, name, platform, credentials, status, updated_at)
        VALUES (@id, @name, @platform, @credentials, 'configured', datetime('now'))
        ON CONFLICT(id) DO UPDATE SET
          name = @name,
          platform = @platform,
          credentials = @credentials,
          status = 'configured',
          updated_at = datetime('now')
      `).run(e),!0}catch(e){return console.error("[DAL] Platform upsert error:",e),!1}},updateStatus(e,r){let a=(0,t.getDb)();try{return a.prepare("UPDATE platforms SET status = ?, updated_at = datetime('now') WHERE id = ?").run(r,e),!0}catch(e){return console.error("[DAL] Platform updateStatus error:",e),!1}},delete(e){let r=(0,t.getDb)();try{return r.prepare("DELETE FROM platforms WHERE id = ?").run(e),!0}catch(e){return console.error("[DAL] Platform delete error:",e),!1}}}])},89796,e=>{"use strict";var t=e.i(2710),r=e.i(35147),a=e.i(55688),o=e.i(87453),s=e.i(3771),n=e.i(47937),i=e.i(5457),d=e.i(17598),p=e.i(41045),l=e.i(71952),u=e.i(59300),c=e.i(85005),T=e.i(69628),E=e.i(3185),m=e.i(47811),h=e.i(93695);e.i(635);var R=e.i(28214),A=e.i(78869),f=e.i(54799),g=e.i(42203);let _={appKey:process.env.MIAOSHOU_APP_KEY||"",appSecret:process.env.MIAOSHOU_APP_SECRET||"",apiBaseUrl:"https://open.miaoshouerp.com/openapi"};async function L(e,t){var r;let a,o=_.appKey,s=_.appSecret;if(!o||!s)try{let e=g.MiaoshouDAL.get();e&&(o=e.appKey||"",s=e.appSecret||"",console.log("[妙手] 使用数据库配置:",o?"已获取AppKey":"无AppKey"))}catch(e){console.error("[妙手] 获取数据库配置失败:",e)}if(!o||!s)throw Error("请先在妙手ERP配置中填写AppKey和AppSecret");let n={appKey:o||"",method:e,timestamp:Date.now().toString(),format:"json",version:"1.0",...t},i=(r=s||"",a=Object.keys(n).sort().map(e=>e+n[e]).join(""),f.default.createHash("md5").update(r+a+r).digest("hex").toUpperCase());n.sign=i;let d=Object.entries(n).map(([e,t])=>`${e}=${encodeURIComponent(t)}`).join("&"),p=`${_.apiBaseUrl}?${d}`;console.log("[妙手API] Request URL:",p.substring(0,150)+"...");try{let e=await fetch(p,{method:"GET",headers:{"Content-Type":"application/json"}});if(!e.ok)throw Error(`妙手API请求失败: ${e.status}`);return await e.json()}catch(e){throw console.error("[妙手API] 调用失败:",e),e}}async function w(e){try{let t=await L("miaoshou.product.get",{platform:"1688",offerId:e});if(t&&0===t.code&&t.data)return{success:!0,data:{offer_id:e,title:t.data.title||t.data.productName||"",price:parseFloat(t.data.price||0),cost_price:parseFloat(t.data.costPrice||0),images:t.data.images||[],details:t.data.description||"",supplier:{name:t.data.supplierName||"",url:t.data.supplierUrl||""},category:t.data.category||"",sales:t.data.sales||0,stock:t.data.stock||0,location:t.data.location||"",weight:t.data.weight||0,skus:t.data.skus||[]}};return null}catch(e){return console.error("[妙手] 查询商品失败:",e),null}}async function x(e){try{let t=await L("miaoshou.product.search",{keywords:e,page:"1",pageSize:"20"});if(t&&0===t.code&&t.data)return t.data.list||[];return[]}catch(e){return console.error("[妙手] 搜索商品失败:",e),[]}}async function N(e){try{let{url:t,offerId:r}=await e.json(),a=r||(t?function(e){for(let t of[/offer\/(\d+)\.html/i,/offer\/-\w+\/(\d+)\.html/i,/view\/(\d+)\.htm/i,/(\d{10,})/i]){let r=e.match(t);if(r&&r[1])return r[1]}return null}(t):null);if(!a)return A.NextResponse.json({success:!1,error:"无法解析1688商品链接，请确保链接格式正确"},{status:400});console.log("[妙手采集] 开始采集商品, offerId:",a);let o=await w(a);if(o)return A.NextResponse.json({success:!0,data:o.data,source:"miaoshou",message:"通过妙手ERP采集成功"});return A.NextResponse.json({success:!1,error:"妙手ERP未找到该商品，请确保：\n1. 已正确配置妙手ERP的AppKey和AppSecret\n2. 该商品已在妙手ERP中存在\n3. 妙手ERP已授权1688平台"},{status:400})}catch(e){return console.error("[妙手采集] 错误:",e),A.NextResponse.json({success:!1,error:e.message||"采集失败，请检查妙手ERP配置"},{status:500})}}async function y(e){try{let{searchParams:t}=new URL(e.url),r=t.get("keywords")||"",a=await x(r);return A.NextResponse.json({success:!0,data:a,source:"miaoshou"})}catch(e){return console.error("[妙手商品列表] 错误:",e),A.NextResponse.json({success:!1,error:e.message||"获取商品列表失败"},{status:500})}}e.s(["GET",()=>y,"POST",()=>N],78027);var U=e.i(78027);let X=new t.AppRouteRouteModule({definition:{kind:r.RouteKind.APP_ROUTE,page:"/api/v1/miaoshou/product/route",pathname:"/api/v1/miaoshou/product",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/src/app/api/v1/miaoshou/product/route.ts",nextConfigOutput:"standalone",userland:U}),{workAsyncStorage:D,workUnitAsyncStorage:S,serverHooks:v}=X;function I(){return(0,a.patchFetch)({workAsyncStorage:D,workUnitAsyncStorage:S})}async function O(e,t,a){X.isDev&&(0,o.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let A="/api/v1/miaoshou/product/route";A=A.replace(/\/index$/,"")||"/";let f=await X.prepare(e,t,{srcPage:A,multiZoneDraftMode:!1});if(!f)return t.statusCode=400,t.end("Bad Request"),null==a.waitUntil||a.waitUntil.call(a,Promise.resolve()),null;let{buildId:g,params:_,nextConfig:L,parsedUrl:w,isDraftMode:x,prerenderManifest:N,routerServerContext:y,isOnDemandRevalidate:U,revalidateOnlyGenerated:D,resolvedPathname:S,clientReferenceManifest:v,serverActionsManifest:I}=f,O=(0,i.normalizeAppPath)(A),C=!!(N.dynamicRoutes[O]||N.routes[S]),F=async()=>((null==y?void 0:y.render404)?await y.render404(e,t,w,!1):t.end("This page could not be found"),null);if(C&&!x){let e=!!N.routes[S],t=N.dynamicRoutes[O];if(t&&!1===t.fallback&&!e){if(L.experimental.adapterPath)return await F();throw new h.NoFallbackError}}let b=null;!C||X.isDev||x||(b="/index"===(b=S)?"/":b);let P=!0===X.isDev||!C,k=C&&!P;I&&v&&(0,n.setManifestsSingleton)({page:A,clientReferenceManifest:v,serverActionsManifest:I});let M=e.method||"GET",j=(0,s.getTracer)(),q=j.getActiveScopeSpan(),K={params:_,prerenderManifest:N,renderOpts:{experimental:{authInterrupts:!!L.experimental.authInterrupts},cacheComponents:!!L.cacheComponents,supportsDynamicResponse:P,incrementalCache:(0,o.getRequestMeta)(e,"incrementalCache"),cacheLifeProfiles:L.cacheLife,waitUntil:a.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,r,a,o)=>X.onRequestError(e,t,a,o,y)},sharedContext:{buildId:g}},H=new d.NodeNextRequest(e),B=new d.NodeNextResponse(t),Y=p.NextRequestAdapter.fromNodeNextRequest(H,(0,p.signalFromNodeResponse)(t));try{let n=async e=>X.handle(Y,K).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let r=j.getRootSpanAttributes();if(!r)return;if(r.get("next.span_type")!==l.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${r.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let a=r.get("next.route");if(a){let t=`${M} ${a}`;e.setAttributes({"next.route":a,"http.route":a,"next.span_name":t}),e.updateName(t)}else e.updateName(`${M} ${A}`)}),i=!!(0,o.getRequestMeta)(e,"minimalMode"),d=async o=>{var s,d;let p=async({previousCacheEntry:r})=>{try{if(!i&&U&&D&&!r)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let s=await n(o);e.fetchMetrics=K.renderOpts.fetchMetrics;let d=K.renderOpts.pendingWaitUntil;d&&a.waitUntil&&(a.waitUntil(d),d=void 0);let p=K.renderOpts.collectedTags;if(!C)return await (0,c.sendResponse)(H,B,s,K.renderOpts.pendingWaitUntil),null;{let e=await s.blob(),t=(0,T.toNodeOutgoingHttpHeaders)(s.headers);p&&(t[m.NEXT_CACHE_TAGS_HEADER]=p),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let r=void 0!==K.renderOpts.collectedRevalidate&&!(K.renderOpts.collectedRevalidate>=m.INFINITE_CACHE)&&K.renderOpts.collectedRevalidate,a=void 0===K.renderOpts.collectedExpire||K.renderOpts.collectedExpire>=m.INFINITE_CACHE?void 0:K.renderOpts.collectedExpire;return{value:{kind:R.CachedRouteKind.APP_ROUTE,status:s.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:r,expire:a}}}}catch(t){throw(null==r?void 0:r.isStale)&&await X.onRequestError(e,t,{routerKind:"App Router",routePath:A,routeType:"route",revalidateReason:(0,u.getRevalidateReason)({isStaticGeneration:k,isOnDemandRevalidate:U})},!1,y),t}},l=await X.handleResponse({req:e,nextConfig:L,cacheKey:b,routeKind:r.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:N,isRoutePPREnabled:!1,isOnDemandRevalidate:U,revalidateOnlyGenerated:D,responseGenerator:p,waitUntil:a.waitUntil,isMinimalMode:i});if(!C)return null;if((null==l||null==(s=l.value)?void 0:s.kind)!==R.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==l||null==(d=l.value)?void 0:d.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});i||t.setHeader("x-nextjs-cache",U?"REVALIDATED":l.isMiss?"MISS":l.isStale?"STALE":"HIT"),x&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let h=(0,T.fromNodeOutgoingHttpHeaders)(l.value.headers);return i&&C||h.delete(m.NEXT_CACHE_TAGS_HEADER),!l.cacheControl||t.getHeader("Cache-Control")||h.get("Cache-Control")||h.set("Cache-Control",(0,E.getCacheControlHeader)(l.cacheControl)),await (0,c.sendResponse)(H,B,new Response(l.value.body,{headers:h,status:l.value.status||200})),null};q?await d(q):await j.withPropagatedContext(e.headers,()=>j.trace(l.BaseServerSpan.handleRequest,{spanName:`${M} ${A}`,kind:s.SpanKind.SERVER,attributes:{"http.method":M,"http.target":e.url}},d))}catch(t){if(t instanceof h.NoFallbackError||await X.onRequestError(e,t,{routerKind:"App Router",routePath:O,routeType:"route",revalidateReason:(0,u.getRevalidateReason)({isStaticGeneration:k,isOnDemandRevalidate:U})},!1,y),C)throw t;return await (0,c.sendResponse)(H,B,new Response(null,{status:500})),null}}e.s(["handler",()=>O,"patchFetch",()=>I,"routeModule",()=>X,"serverHooks",()=>v,"workAsyncStorage",()=>D,"workUnitAsyncStorage",()=>S],89796)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__c12a4db1._.js.map