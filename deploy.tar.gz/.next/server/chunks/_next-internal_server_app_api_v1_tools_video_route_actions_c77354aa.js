module.exports=[34095,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_tools_video_route_actions_c77354aa.js.map