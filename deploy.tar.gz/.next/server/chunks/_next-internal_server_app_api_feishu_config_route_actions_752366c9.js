module.exports=[97564,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_feishu_config_route_actions_752366c9.js.map