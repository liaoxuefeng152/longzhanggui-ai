module.exports=[82066,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_pricing_templates_route_actions_5b4a62e0.js.map