module.exports=[18622,(e,t,r)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},70406,(e,t,r)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},93695,(e,t,r)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},16494,e=>e.a(async(t,r)=>{try{let t=await e.y("coze-coding-dev-sdk-e40545b728faa7b1");e.n(t),r()}catch(e){r(e)}},!0),5976,e=>e.a(async(t,r)=>{try{var n=e.i(16494),a=t([n]);[n]=a.then?(await a)():a;let s={en:"Please respond in English",th:"请用泰语回复，使用礼貌敬语",vi:"请用越南语回复，使用礼貌用语",ms:"请用马来语回复",id:"请用印尼语回复，使用礼貌用语",ph:"请用菲律宾语回复"},i=`你是龙掌柜智能客服助手，专门为跨境电商卖家提供客服回复支持。

## 回复原则

### 1. 友好专业
- 使用礼貌用语
- 表达同理心
- 积极解决问题

### 2. 清晰简洁
- 直接回答问题
- 避免复杂表述
- 提供具体信息

### 3. 积极正面
- 承认问题并道歉
- 提供解决方案
- 表达感谢

### 4. 文化适应
- 尊重当地文化
- 使用恰当称呼
- 避免文化禁忌

## 消息类型处理

### inquiry（询盘）
- 热情回复
- 提供详细产品信息
- 引导下单

### order（订单查询）
- 确认订单状态
- 提供物流信息
- 预计送达时间

### logistics（物流查询）
- 提供追踪信息
- 解释物流状态
- 安抚客户情绪

### complaint（投诉）
- 诚恳道歉
- 承担责任
- 提供补偿方案

### refund（退款）
- 了解退款原因
- 说明退款流程
- 尝试挽留

### review（评价）
- 感谢评价
- 正面回应问题
- 邀请再次购买`;async function o(e){try{let{customerMessage:t,messageType:r,targetLanguage:a,orderInfo:o,tone:l="friendly",previousMessages:d}=await e.json();if(!t)return new Response(JSON.stringify({success:!1,error:"请提供客户消息"}),{status:400,headers:{"Content-Type":"application/json"}});let c={inquiry:"询盘咨询",order:"订单查询",logistics:"物流查询",complaint:"投诉处理",refund:"退款申请",review:"评价回复"},u=`
## 客户消息
"${t}"

## 消息类型
${c[r]||"通用咨询"}

## 回复要求
- 目标语言：${s[a]||s.en}
- 语气风格：${{friendly:"使用友好亲切的语气，像朋友一样交流",professional:"使用专业正式的语气，保持商务礼仪",apologetic:"使用诚恳道歉的语气，表达歉意和补救意愿"}[l]}
`;o&&(u+=`
## 订单信息
${o.orderId?`- 订单号：${o.orderId}`:""}
${o.status?`- 订单状态：${o.status}`:""}
${o.trackingNumber?`- 物流单号：${o.trackingNumber}`:""}
${o.estimatedDelivery?`- 预计送达：${o.estimatedDelivery}`:""}
`),d?.length&&(u+=`
## 对话历史
${d.map(e=>`${"customer"===e.role?"客户":"客服"}: ${e.content}`).join("\n")}
`),u+=`
请生成专业、友好、有效的客服回复。直接输出回复内容，不要解释。`;let p=n.HeaderUtils.extractForwardHeaders(e.headers),h=new n.Config,v=new n.LLMClient(h,p),y=new TextEncoder,m=new ReadableStream({async start(e){try{let t=[{role:"system",content:i},{role:"user",content:u}];e.enqueue(y.encode(`data: ${JSON.stringify({type:"start",messageType:r,label:c[r]})}

`));let n=v.stream(t,{model:"doubao-seed-1-8-251228",temperature:.7}),a="";for await(let t of n)if(t.content){let r=t.content.toString();a+=r,e.enqueue(y.encode(`data: ${JSON.stringify({type:"content",content:r})}

`))}e.enqueue(y.encode(`data: ${JSON.stringify({type:"done",fullResponse:a})}

`)),e.close()}catch(t){console.error("CS reply generation error:",t),e.enqueue(y.encode(`data: ${JSON.stringify({type:"error",message:"生成失败，请重试"})}

`)),e.close()}}});return new Response(m,{headers:{"Content-Type":"text/event-stream","Cache-Control":"no-cache",Connection:"keep-alive"}})}catch(e){return console.error("CS API error:",e),new Response(JSON.stringify({success:!1,error:"服务器内部错误"}),{status:500,headers:{"Content-Type":"application/json"}})}}e.s(["POST",()=>o]),r()}catch(e){r(e)}},!1),38041,e=>e.a(async(t,r)=>{try{var n=e.i(2710),a=e.i(35147),o=e.i(55688),s=e.i(87453),i=e.i(3771),l=e.i(47937),d=e.i(5457),c=e.i(17598),u=e.i(41045),p=e.i(71952),h=e.i(59300),v=e.i(85005),y=e.i(69628),m=e.i(3185),x=e.i(47811),g=e.i(93695);e.i(635);var R=e.i(28214),f=e.i(5976),w=t([f]);[f]=w.then?(await w)():w;let b=new n.AppRouteRouteModule({definition:{kind:a.RouteKind.APP_ROUTE,page:"/api/v1/tools/customer-service/route",pathname:"/api/v1/tools/customer-service",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/src/app/api/v1/tools/customer-service/route.ts",nextConfigOutput:"standalone",userland:f}),{workAsyncStorage:N,workUnitAsyncStorage:A,serverHooks:S}=b;function C(){return(0,o.patchFetch)({workAsyncStorage:N,workUnitAsyncStorage:A})}async function E(e,t,r){b.isDev&&(0,s.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let n="/api/v1/tools/customer-service/route";n=n.replace(/\/index$/,"")||"/";let o=await b.prepare(e,t,{srcPage:n,multiZoneDraftMode:!1});if(!o)return t.statusCode=400,t.end("Bad Request"),null==r.waitUntil||r.waitUntil.call(r,Promise.resolve()),null;let{buildId:f,params:w,nextConfig:C,parsedUrl:E,isDraftMode:N,prerenderManifest:A,routerServerContext:S,isOnDemandRevalidate:T,revalidateOnlyGenerated:O,resolvedPathname:$,clientReferenceManifest:P,serverActionsManifest:q}=o,k=(0,d.normalizeAppPath)(n),_=!!(A.dynamicRoutes[k]||A.routes[$]),j=async()=>((null==S?void 0:S.render404)?await S.render404(e,t,E,!1):t.end("This page could not be found"),null);if(_&&!N){let e=!!A.routes[$],t=A.dynamicRoutes[k];if(t&&!1===t.fallback&&!e){if(C.experimental.adapterPath)return await j();throw new g.NoFallbackError}}let H=null;!_||b.isDev||N||(H=$,H="/index"===H?"/":H);let I=!0===b.isDev||!_,U=_&&!I;q&&P&&(0,l.setManifestsSingleton)({page:n,clientReferenceManifest:P,serverActionsManifest:q});let D=e.method||"GET",M=(0,i.getTracer)(),F=M.getActiveScopeSpan(),K={params:w,prerenderManifest:A,renderOpts:{experimental:{authInterrupts:!!C.experimental.authInterrupts},cacheComponents:!!C.cacheComponents,supportsDynamicResponse:I,incrementalCache:(0,s.getRequestMeta)(e,"incrementalCache"),cacheLifeProfiles:C.cacheLife,waitUntil:r.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,r,n,a)=>b.onRequestError(e,t,n,a,S)},sharedContext:{buildId:f}},L=new c.NodeNextRequest(e),J=new c.NodeNextResponse(t),B=u.NextRequestAdapter.fromNodeNextRequest(L,(0,u.signalFromNodeResponse)(t));try{let o=async e=>b.handle(B,K).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let r=M.getRootSpanAttributes();if(!r)return;if(r.get("next.span_type")!==p.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${r.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let a=r.get("next.route");if(a){let t=`${D} ${a}`;e.setAttributes({"next.route":a,"http.route":a,"next.span_name":t}),e.updateName(t)}else e.updateName(`${D} ${n}`)}),l=!!(0,s.getRequestMeta)(e,"minimalMode"),d=async s=>{var i,d;let c=async({previousCacheEntry:a})=>{try{if(!l&&T&&O&&!a)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let n=await o(s);e.fetchMetrics=K.renderOpts.fetchMetrics;let i=K.renderOpts.pendingWaitUntil;i&&r.waitUntil&&(r.waitUntil(i),i=void 0);let d=K.renderOpts.collectedTags;if(!_)return await (0,v.sendResponse)(L,J,n,K.renderOpts.pendingWaitUntil),null;{let e=await n.blob(),t=(0,y.toNodeOutgoingHttpHeaders)(n.headers);d&&(t[x.NEXT_CACHE_TAGS_HEADER]=d),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let r=void 0!==K.renderOpts.collectedRevalidate&&!(K.renderOpts.collectedRevalidate>=x.INFINITE_CACHE)&&K.renderOpts.collectedRevalidate,a=void 0===K.renderOpts.collectedExpire||K.renderOpts.collectedExpire>=x.INFINITE_CACHE?void 0:K.renderOpts.collectedExpire;return{value:{kind:R.CachedRouteKind.APP_ROUTE,status:n.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:r,expire:a}}}}catch(t){throw(null==a?void 0:a.isStale)&&await b.onRequestError(e,t,{routerKind:"App Router",routePath:n,routeType:"route",revalidateReason:(0,h.getRevalidateReason)({isStaticGeneration:U,isOnDemandRevalidate:T})},!1,S),t}},u=await b.handleResponse({req:e,nextConfig:C,cacheKey:H,routeKind:a.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:A,isRoutePPREnabled:!1,isOnDemandRevalidate:T,revalidateOnlyGenerated:O,responseGenerator:c,waitUntil:r.waitUntil,isMinimalMode:l});if(!_)return null;if((null==u||null==(i=u.value)?void 0:i.kind)!==R.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==u||null==(d=u.value)?void 0:d.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});l||t.setHeader("x-nextjs-cache",T?"REVALIDATED":u.isMiss?"MISS":u.isStale?"STALE":"HIT"),N&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let p=(0,y.fromNodeOutgoingHttpHeaders)(u.value.headers);return l&&_||p.delete(x.NEXT_CACHE_TAGS_HEADER),!u.cacheControl||t.getHeader("Cache-Control")||p.get("Cache-Control")||p.set("Cache-Control",(0,m.getCacheControlHeader)(u.cacheControl)),await (0,v.sendResponse)(L,J,new Response(u.value.body,{headers:p,status:u.value.status||200})),null};F?await d(F):await M.withPropagatedContext(e.headers,()=>M.trace(p.BaseServerSpan.handleRequest,{spanName:`${D} ${n}`,kind:i.SpanKind.SERVER,attributes:{"http.method":D,"http.target":e.url}},d))}catch(t){if(t instanceof g.NoFallbackError||await b.onRequestError(e,t,{routerKind:"App Router",routePath:k,routeType:"route",revalidateReason:(0,h.getRevalidateReason)({isStaticGeneration:U,isOnDemandRevalidate:T})},!1,S),_)throw t;return await (0,v.sendResponse)(L,J,new Response(null,{status:500})),null}}e.s(["handler",()=>E,"patchFetch",()=>C,"routeModule",()=>b,"serverHooks",()=>S,"workAsyncStorage",()=>N,"workUnitAsyncStorage",()=>A]),r()}catch(e){r(e)}},!1)];

//# sourceMappingURL=%5Broot-of-the-server%5D__7c12fa4d._.js.map