module.exports=[96063,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_erp_products_route_actions_08ccc461.js.map