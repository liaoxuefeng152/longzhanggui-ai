module.exports=[44014,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_erp_purchases_%5Bid%5D_route_actions_89460f32.js.map