module.exports=[25331,e=>e.a(async(t,a)=>{try{var n=e.i(16494),r=t([n]);[n]=r.then?(await r)():r;let o=new Map,s=`你是龙掌柜智能运营助手，专为跨境电商卖家提供一站式运营服务。

## 你的核心能力

### 1. 选品分析 🎯
- 市场趋势分析
- 竞品研究
- 蓝海类目挖掘
- 选品报告生成

### 2. 商品采集 📦
- 支持1688、淘宝、天猫、京东、拼多多
- 单个/批量商品采集
- 商品信息提取

### 3. 图片/视频设计 🎨
- 商品主图生成
- 生活场景图
- AI视频生成

### 4. Listing优化 📝
- 标题生成与优化
- 五点描述
- SEO关键词
- 多语言支持（英文/印尼语/泰语/越南语/马来语）

### 5. 智能定价 💰
- 保本价计算
- 利润空间验证
- 价格策略建议

### 6. 广告优化 📊
- ROI/ACOS分析
- 智能出价建议
- 广告效果优化

### 7. 客服支持 💬
- 多语言客服回复
- 订单/物流查询
- 售后纠纷处理

### 8. 数据复盘 📈
- 流量分析
- 转化分析
- 利润分析

## 回复风格
- 专业、简洁、实用
- 使用Markdown格式
- 提供可执行的建议
- 必要时引导用户到系统对应功能模块

## 特殊指令
- 当用户需要选品时，提供详细的市场分析和建议
- 当用户需要定价时，提醒考虑成本、物流、佣金等因素
- 当用户需要客服回复时，生成专业、友好的回复模板`,l={product_selection:["选品","爆款","热卖","趋势","蓝海","类目","竞品分析","市场分析","推荐产品"],product_scrape:["采集","爬取","抓取","1688","淘宝","京东","拼多多","teum","商品信息"],image_design:["图片","主图","场景图","白底","抠图","图片处理","图片翻译"],video_generation:["视频","视频生成","产品视频","展示视频","短视频"],listing_optimize:["listing","标题","描述","五点","关键词","seo","文案","优化"],pricing:["定价","价格","利润","成本","售价","保本","利润率"],profit_analysis:["利润分析","盈亏","成本分析","利润报表","每日利润"],ad_optimization:["广告","roi","acos","投放","推广","出价","campaign"],customer_service:["客服","回复","消息","差评","纠纷","退款","退货","售后"],compliance_check:["合规","风险","违规","检查","体检","封店"],data_analysis:["数据","报表","分析","日报","周报","复盘","统计"],general_chat:[]};async function i(e){try{let{message:t,session_id:a="default",history:r=[]}=await e.json();if(!t)return new Response(JSON.stringify({detail:"消息不能为空"}),{status:400,headers:{"Content-Type":"application/json"}});let i=o.get(a);i||(i={messages:[]},o.set(a,i));let c=function(e){let t=e.toLowerCase();for(let[e,a]of Object.entries(l))if("general_chat"!==e){for(let n of a)if(t.includes(n.toLowerCase()))return e}return"general_chat"}(t),d={product_selection:`
## 当前任务：选品分析
请按以下结构回复：
1. **市场趋势**：分析当前市场趋势
2. **推荐方向**：提供3-5个选品方向
3. **风险评估**：指出潜在风险
4. **行动建议**：给出具体可执行的下一步

如果用户提供了具体需求（如目标市场、预算），请针对性地分析。`,product_scrape:`
## 当前任务：商品采集
请引导用户提供：
1. 商品链接（支持1688、淘宝等平台）
2. 采集需求（基本信息/详细信息/批量采集）

如果用户提供了链接，请分析该商品的基本信息。`,image_design:`
## 当前任务：图片设计
请了解用户需求：
1. 图片类型（主图/场景图/信息图）
2. 目标平台（Shopee/Lazada/TikTok/Amazon）
3. 特殊要求（白底/翻译/尺寸）

提供专业的图片设计建议。`,video_generation:`
## 当前任务：视频生成
请了解用户需求：
1. 视频类型（展示视频/解说视频/短视频）
2. 视频时长
3. 产品特点

提供视频创意和脚本建议。`,listing_optimize:`
## 当前任务：Listing优化
请按以下步骤处理：
1. 了解产品基本信息
2. 目标站点/语言
3. 优化目标（标题/描述/关键词）

输出专业的Listing内容。`,pricing:`
## 当前任务：智能定价
请收集以下信息：
1. 采购成本
2. 目标平台和站点
3. 物流方式
4. 预期利润率

使用公式：售价 = (成本 + 物流 + 佣金 + 广告费) / (1 - 利润率)`,profit_analysis:`
## 当前任务：利润分析
请引导用户：
1. 查看利润报表（ERP系统 > 财务管理）
2. 分析亏损商品
3. 优化建议`,ad_optimization:`
## 当前任务：广告优化
请收集以下信息：
1. 广告数据（花费、点击、转化）
2. 当前ROI/ACOS
3. 优化目标

提供具体的优化建议。`,customer_service:`
## 当前任务：客服回复
请了解：
1. 客户问题类型
2. 订单状态
3. 目标回复语言

生成专业、友好的客服回复。`,compliance_check:`
## 当前任务：合规检查
请引导用户：
1. 选择检查类型（Listing风险/图片风险）
2. 提供商品信息
3. 查看体检报告`,data_analysis:`
## 当前任务：数据分析
请引导用户：
1. 选择分析维度（流量/转化/价格）
2. 时间范围
3. 分析目标

提供数据洞察和建议。`,general_chat:""}[c],u=[{role:"system",content:s+d}],p=i.messages.slice(-40);u.push(...p),u.push({role:"user",content:t});let h=n.HeaderUtils.extractForwardHeaders(e.headers),g=new n.Config,m=new n.LLMClient(g,h),R=new TextEncoder,f=new ReadableStream({async start(e){try{let a=`data: ${JSON.stringify({type:"intent",intent:c,label:{product_selection:"🎯 选品分析",product_scrape:"📦 商品采集",image_design:"🎨 图片设计",video_generation:"🎬 视频生成",listing_optimize:"📝 Listing优化",pricing:"💰 智能定价",profit_analysis:"📊 利润分析",ad_optimization:"📈 广告优化",customer_service:"💬 客服支持",compliance_check:"✅ 合规检查",data_analysis:"📉 数据分析",general_chat:"💬 智能对话"}[c]})}

`;e.enqueue(R.encode(a));let n=m.stream(u,{model:"doubao-seed-1-8-251228",temperature:.7,thinking:"disabled"}),r="";for await(let t of n)if(t.content){let a=t.content.toString();r+=a;let n=`data: ${JSON.stringify({type:"content",content:a})}

`;e.enqueue(R.encode(n))}i.messages.push({role:"user",content:t},{role:"assistant",content:r});let o=`data: ${JSON.stringify({type:"done",fullResponse:r})}

`;e.enqueue(R.encode(o)),e.close()}catch(a){console.error("Stream error:",a);let t=`data: ${JSON.stringify({type:"error",message:"AI服务暂时不可用，请稍后重试"})}

`;e.enqueue(R.encode(t)),e.close()}}});return new Response(f,{headers:{"Content-Type":"text/event-stream","Cache-Control":"no-cache",Connection:"keep-alive"}})}catch(e){return console.error("Chat API error:",e),new Response(JSON.stringify({detail:"服务器内部错误"}),{status:500,headers:{"Content-Type":"application/json"}})}}e.s(["POST",()=>i]),a()}catch(e){a(e)}},!1),97678,e=>e.a(async(t,a)=>{try{var n=e.i(2710),r=e.i(35147),i=e.i(55688),o=e.i(87453),s=e.i(3771),l=e.i(47937),c=e.i(5457),d=e.i(17598),u=e.i(41045),p=e.i(71952),h=e.i(59300),g=e.i(85005),m=e.i(69628),R=e.i(3185),f=e.i(47811),v=e.i(93695);e.i(635);var _=e.i(28214),y=e.i(25331),w=t([y]);[y]=w.then?(await w)():w;let A=new n.AppRouteRouteModule({definition:{kind:r.RouteKind.APP_ROUTE,page:"/api/v1/ai/chat-stream/route",pathname:"/api/v1/ai/chat-stream",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/src/app/api/v1/ai/chat-stream/route.ts",nextConfigOutput:"standalone",userland:y}),{workAsyncStorage:x,workUnitAsyncStorage:O,serverHooks:S}=A;function C(){return(0,i.patchFetch)({workAsyncStorage:x,workUnitAsyncStorage:O})}async function E(e,t,a){A.isDev&&(0,o.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let n="/api/v1/ai/chat-stream/route";n=n.replace(/\/index$/,"")||"/";let i=await A.prepare(e,t,{srcPage:n,multiZoneDraftMode:!1});if(!i)return t.statusCode=400,t.end("Bad Request"),null==a.waitUntil||a.waitUntil.call(a,Promise.resolve()),null;let{buildId:y,params:w,nextConfig:C,parsedUrl:E,isDraftMode:x,prerenderManifest:O,routerServerContext:S,isOnDemandRevalidate:T,revalidateOnlyGenerated:N,resolvedPathname:b,clientReferenceManifest:P,serverActionsManifest:k}=i,I=(0,c.normalizeAppPath)(n),H=!!(O.dynamicRoutes[I]||O.routes[b]),q=async()=>((null==S?void 0:S.render404)?await S.render404(e,t,E,!1):t.end("This page could not be found"),null);if(H&&!x){let e=!!O.routes[b],t=O.dynamicRoutes[I];if(t&&!1===t.fallback&&!e){if(C.experimental.adapterPath)return await q();throw new v.NoFallbackError}}let U=null;!H||A.isDev||x||(U=b,U="/index"===U?"/":U);let L=!0===A.isDev||!H,M=H&&!L;k&&P&&(0,l.setManifestsSingleton)({page:n,clientReferenceManifest:P,serverActionsManifest:k});let D=e.method||"GET",$=(0,s.getTracer)(),j=$.getActiveScopeSpan(),z={params:w,prerenderManifest:O,renderOpts:{experimental:{authInterrupts:!!C.experimental.authInterrupts},cacheComponents:!!C.cacheComponents,supportsDynamicResponse:L,incrementalCache:(0,o.getRequestMeta)(e,"incrementalCache"),cacheLifeProfiles:C.cacheLife,waitUntil:a.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,a,n,r)=>A.onRequestError(e,t,n,r,S)},sharedContext:{buildId:y}},F=new d.NodeNextRequest(e),K=new d.NodeNextResponse(t),J=u.NextRequestAdapter.fromNodeNextRequest(F,(0,u.signalFromNodeResponse)(t));try{let i=async e=>A.handle(J,z).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let a=$.getRootSpanAttributes();if(!a)return;if(a.get("next.span_type")!==p.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${a.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let r=a.get("next.route");if(r){let t=`${D} ${r}`;e.setAttributes({"next.route":r,"http.route":r,"next.span_name":t}),e.updateName(t)}else e.updateName(`${D} ${n}`)}),l=!!(0,o.getRequestMeta)(e,"minimalMode"),c=async o=>{var s,c;let d=async({previousCacheEntry:r})=>{try{if(!l&&T&&N&&!r)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let n=await i(o);e.fetchMetrics=z.renderOpts.fetchMetrics;let s=z.renderOpts.pendingWaitUntil;s&&a.waitUntil&&(a.waitUntil(s),s=void 0);let c=z.renderOpts.collectedTags;if(!H)return await (0,g.sendResponse)(F,K,n,z.renderOpts.pendingWaitUntil),null;{let e=await n.blob(),t=(0,m.toNodeOutgoingHttpHeaders)(n.headers);c&&(t[f.NEXT_CACHE_TAGS_HEADER]=c),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let a=void 0!==z.renderOpts.collectedRevalidate&&!(z.renderOpts.collectedRevalidate>=f.INFINITE_CACHE)&&z.renderOpts.collectedRevalidate,r=void 0===z.renderOpts.collectedExpire||z.renderOpts.collectedExpire>=f.INFINITE_CACHE?void 0:z.renderOpts.collectedExpire;return{value:{kind:_.CachedRouteKind.APP_ROUTE,status:n.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:a,expire:r}}}}catch(t){throw(null==r?void 0:r.isStale)&&await A.onRequestError(e,t,{routerKind:"App Router",routePath:n,routeType:"route",revalidateReason:(0,h.getRevalidateReason)({isStaticGeneration:M,isOnDemandRevalidate:T})},!1,S),t}},u=await A.handleResponse({req:e,nextConfig:C,cacheKey:U,routeKind:r.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:O,isRoutePPREnabled:!1,isOnDemandRevalidate:T,revalidateOnlyGenerated:N,responseGenerator:d,waitUntil:a.waitUntil,isMinimalMode:l});if(!H)return null;if((null==u||null==(s=u.value)?void 0:s.kind)!==_.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==u||null==(c=u.value)?void 0:c.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});l||t.setHeader("x-nextjs-cache",T?"REVALIDATED":u.isMiss?"MISS":u.isStale?"STALE":"HIT"),x&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let p=(0,m.fromNodeOutgoingHttpHeaders)(u.value.headers);return l&&H||p.delete(f.NEXT_CACHE_TAGS_HEADER),!u.cacheControl||t.getHeader("Cache-Control")||p.get("Cache-Control")||p.set("Cache-Control",(0,R.getCacheControlHeader)(u.cacheControl)),await (0,g.sendResponse)(F,K,new Response(u.value.body,{headers:p,status:u.value.status||200})),null};j?await c(j):await $.withPropagatedContext(e.headers,()=>$.trace(p.BaseServerSpan.handleRequest,{spanName:`${D} ${n}`,kind:s.SpanKind.SERVER,attributes:{"http.method":D,"http.target":e.url}},c))}catch(t){if(t instanceof v.NoFallbackError||await A.onRequestError(e,t,{routerKind:"App Router",routePath:I,routeType:"route",revalidateReason:(0,h.getRevalidateReason)({isStaticGeneration:M,isOnDemandRevalidate:T})},!1,S),H)throw t;return await (0,g.sendResponse)(F,K,new Response(null,{status:500})),null}}e.s(["handler",()=>E,"patchFetch",()=>C,"routeModule",()=>A,"serverHooks",()=>S,"workAsyncStorage",()=>x,"workUnitAsyncStorage",()=>O]),a()}catch(e){a(e)}},!1)];

//# sourceMappingURL=_47f75e88._.js.map