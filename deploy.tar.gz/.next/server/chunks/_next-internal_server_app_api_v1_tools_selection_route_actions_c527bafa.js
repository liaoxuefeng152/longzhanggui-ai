module.exports=[60015,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_tools_selection_route_actions_c527bafa.js.map