module.exports=[94473,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_tools_pricing_route_actions_8e547641.js.map