module.exports=[6059,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_workflows_pricing-templates_%5Bid%5D_page_actions_2413b095.js.map