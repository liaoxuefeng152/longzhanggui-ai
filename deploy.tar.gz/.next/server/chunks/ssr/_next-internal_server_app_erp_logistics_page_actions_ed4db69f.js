module.exports=[92308,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_erp_logistics_page_actions_ed4db69f.js.map