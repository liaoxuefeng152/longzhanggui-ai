module.exports=[490,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_erp_purchase_page_actions_8bff89af.js.map