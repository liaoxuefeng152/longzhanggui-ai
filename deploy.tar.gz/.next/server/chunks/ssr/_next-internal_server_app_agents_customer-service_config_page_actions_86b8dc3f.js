module.exports=[95394,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_agents_customer-service_config_page_actions_86b8dc3f.js.map