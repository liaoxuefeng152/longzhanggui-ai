module.exports=[94767,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_agents_config_page_actions_0a4bc64b.js.map