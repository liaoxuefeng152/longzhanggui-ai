module.exports=[20696,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_erp_finance_page_actions_1fdec45b.js.map