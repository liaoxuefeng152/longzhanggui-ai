module.exports=[12207,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_agents_image-design_page_actions_6f61461a.js.map