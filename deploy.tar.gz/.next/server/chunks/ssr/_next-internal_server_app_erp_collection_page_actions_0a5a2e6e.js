module.exports=[9887,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_erp_collection_page_actions_0a5a2e6e.js.map