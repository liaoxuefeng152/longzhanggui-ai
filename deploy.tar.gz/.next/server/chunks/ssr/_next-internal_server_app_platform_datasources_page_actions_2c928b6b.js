module.exports=[65252,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_platform_datasources_page_actions_2c928b6b.js.map