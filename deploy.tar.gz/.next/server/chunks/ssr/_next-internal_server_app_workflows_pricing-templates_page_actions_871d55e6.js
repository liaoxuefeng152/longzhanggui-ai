module.exports=[28819,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_workflows_pricing-templates_page_actions_871d55e6.js.map