module.exports=[66794,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_packages_payment_page_actions_c773fad1.js.map