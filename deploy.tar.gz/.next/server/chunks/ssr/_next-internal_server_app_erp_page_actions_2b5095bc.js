module.exports=[8742,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_erp_page_actions_2b5095bc.js.map