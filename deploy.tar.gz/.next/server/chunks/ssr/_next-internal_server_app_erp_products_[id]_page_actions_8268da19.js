module.exports=[52426,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_erp_products_%5Bid%5D_page_actions_8268da19.js.map