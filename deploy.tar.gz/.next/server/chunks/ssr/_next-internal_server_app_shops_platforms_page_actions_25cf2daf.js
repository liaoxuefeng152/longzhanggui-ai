module.exports=[15367,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_shops_platforms_page_actions_25cf2daf.js.map