module.exports=[33744,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_agents_data-review_config_page_actions_c5de9b43.js.map