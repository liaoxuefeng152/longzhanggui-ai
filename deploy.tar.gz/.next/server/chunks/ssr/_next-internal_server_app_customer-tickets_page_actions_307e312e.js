module.exports=[31326,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_customer-tickets_page_actions_307e312e.js.map