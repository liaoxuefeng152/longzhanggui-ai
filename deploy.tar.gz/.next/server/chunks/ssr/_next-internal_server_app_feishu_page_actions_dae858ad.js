module.exports=[85275,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_feishu_page_actions_dae858ad.js.map