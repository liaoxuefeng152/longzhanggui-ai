module.exports=[37965,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_agents_advertising_page_actions_423d4ac9.js.map