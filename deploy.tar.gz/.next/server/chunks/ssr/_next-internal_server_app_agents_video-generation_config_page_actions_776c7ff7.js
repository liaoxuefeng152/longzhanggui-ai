module.exports=[90799,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_agents_video-generation_config_page_actions_776c7ff7.js.map