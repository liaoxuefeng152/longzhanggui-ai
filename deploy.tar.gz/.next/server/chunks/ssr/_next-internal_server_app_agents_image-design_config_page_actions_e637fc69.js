module.exports=[38500,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_agents_image-design_config_page_actions_e637fc69.js.map