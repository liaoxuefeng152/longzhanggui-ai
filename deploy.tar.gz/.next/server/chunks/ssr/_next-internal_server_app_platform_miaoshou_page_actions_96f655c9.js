module.exports=[42167,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_platform_miaoshou_page_actions_96f655c9.js.map