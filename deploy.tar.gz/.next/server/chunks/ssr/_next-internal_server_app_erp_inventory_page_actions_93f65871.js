module.exports=[80124,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_erp_inventory_page_actions_93f65871.js.map