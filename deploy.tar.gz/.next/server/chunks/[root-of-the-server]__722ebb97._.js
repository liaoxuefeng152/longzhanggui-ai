module.exports=[70406,(e,t,r)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},93695,(e,t,r)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},18622,(e,t,r)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},24725,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},14747,(e,t,r)=>{t.exports=e.x("path",()=>require("path"))},94824,(e,t,r)=>{t.exports=e.x("better-sqlite3-6af3159004069310",()=>require("better-sqlite3-6af3159004069310"))},22734,(e,t,r)=>{t.exports=e.x("fs",()=>require("fs"))},84501,e=>{"use strict";var t=e.i(94824),r=e.i(14747),a=e.i(22734);let s=r.default.join(process.cwd(),"data","lobster.db"),o=r.default.dirname(s);a.default.existsSync(o)||a.default.mkdirSync(o,{recursive:!0});let n=null;function i(){return n||((n=new t.default(s)).pragma("journal_mode = WAL"),n.pragma("foreign_keys = ON"),function(e){e.exec(`
    CREATE TABLE IF NOT EXISTS platforms (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      platform TEXT NOT NULL,
      credentials TEXT DEFAULT '{}',
      status TEXT DEFAULT 'disconnected',
      last_sync TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    )
  `),e.exec(`
    CREATE TABLE IF NOT EXISTS miaoshou_config (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      phone TEXT NOT NULL,
      password TEXT NOT NULL,
      cookies TEXT,
      status TEXT DEFAULT 'disconnected',
      last_sync TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    )
  `);try{e.exec("ALTER TABLE miaoshou_config ADD COLUMN app_key TEXT"),e.exec("ALTER TABLE miaoshou_config ADD COLUMN app_secret TEXT")}catch(e){}e.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      username TEXT NOT NULL UNIQUE,
      password TEXT NOT NULL,
      email TEXT,
      role TEXT DEFAULT 'client',
      avatar TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    )
  `),e.exec(`
    CREATE TABLE IF NOT EXISTS products (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      name_en TEXT,
      sku TEXT,
      category TEXT,
      cost_price REAL DEFAULT 0,
      price REAL DEFAULT 0,
      stock INTEGER DEFAULT 0,
      status TEXT DEFAULT 'draft',
      source TEXT,
      source_url TEXT,
      supplier_name TEXT,
      supplier_id TEXT,
      images TEXT DEFAULT '[]',
      video_url TEXT,
      weight REAL,
      dimensions TEXT,
      description TEXT,
      description_en TEXT,
      keywords TEXT,
      attributes TEXT DEFAULT '{}',
      shop_id TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    )
  `),e.exec(`
    CREATE TABLE IF NOT EXISTS collection_products (
      id TEXT PRIMARY KEY,
      collection_id TEXT,
      product_id TEXT,
      product_name TEXT NOT NULL,
      source TEXT,
      source_url TEXT,
      source_id TEXT,
      supplier_name TEXT,
      cost_price REAL DEFAULT 0,
      images TEXT DEFAULT '[]',
      category TEXT,
      claimed INTEGER DEFAULT 0,
      claimed_by TEXT,
      claimed_at TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    )
  `),e.exec(`
    CREATE TABLE IF NOT EXISTS feishu_config (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      app_id TEXT NOT NULL,
      app_secret TEXT NOT NULL,
      bot_name TEXT,
      webhook_url TEXT,
      push_enabled INTEGER DEFAULT 0,
      alert_enabled INTEGER DEFAULT 1,
      alert_threshold INTEGER DEFAULT 10,
      templates TEXT DEFAULT '{}',
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    )
  `),e.exec(`
    CREATE TABLE IF NOT EXISTS import_history (
      id TEXT PRIMARY KEY,
      type TEXT NOT NULL,
      file_name TEXT,
      status TEXT DEFAULT 'pending',
      total_rows INTEGER DEFAULT 0,
      success_rows INTEGER DEFAULT 0,
      error_rows INTEGER DEFAULT 0,
      error_log TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      completed_at TEXT
    )
  `),0===e.prepare("SELECT COUNT(*) as count FROM users WHERE role = ?").get("admin").count&&e.prepare(`
      INSERT INTO users (id, username, password, email, role) VALUES (?, ?, ?, ?, ?)
    `).run("admin","admin","admin123","admin@example.com","admin"),0===e.prepare("SELECT COUNT(*) as count FROM feishu_config").get().count&&e.prepare(`
      INSERT INTO feishu_config (app_id, app_secret, bot_name, push_enabled, alert_enabled)
      VALUES (?, ?, ?, ?, ?)
    `).run("","","龙掌柜跨境AI全能助手",0,1),console.log("[DB] Database tables initialized")}(n)),n}e.s(["getDb",()=>i])},42203,e=>{"use strict";var t=e.i(84501);e.s(["MiaoshouDAL",0,{get(){let e=(0,t.getDb)().prepare("SELECT * FROM miaoshou_config LIMIT 1").get();if(e)return{id:String(e.id),phone:e.phone,password:e.password,cookies:e.cookies,appKey:e.app_key,appSecret:e.app_secret,status:e.status,lastSync:e.last_sync,updated_at:e.updated_at}},save(e){let r=(0,t.getDb)();try{return r.prepare("DELETE FROM miaoshou_config").run(),r.prepare(`
        INSERT INTO miaoshou_config (phone, password, cookies, app_key, app_secret, status, updated_at)
        VALUES (?, ?, ?, ?, ?, 'disconnected', datetime('now'))
      `).run(e.phone,e.password,e.cookies||null,e.appKey||null,e.appSecret||null),!0}catch(e){return console.error("[DAL] Miaoshou save error:",e),!1}},updateStatus(e){let r=(0,t.getDb)();try{return r.prepare("UPDATE miaoshou_config SET status = ?, updated_at = datetime('now')").run(e),!0}catch(e){return console.error("[DAL] Miaoshou updateStatus error:",e),!1}},updateCookies(e){let r=(0,t.getDb)();try{return r.prepare("UPDATE miaoshou_config SET cookies = ?, updated_at = datetime('now')").run(e),!0}catch(e){return console.error("[DAL] Miaoshou updateCookies error:",e),!1}}},"PlatformDAL",0,{getAll:()=>(0,t.getDb)().prepare("SELECT * FROM platforms ORDER BY created_at DESC").all(),getById:e=>(0,t.getDb)().prepare("SELECT * FROM platforms WHERE id = ?").get(e),upsert(e){let r=(0,t.getDb)();try{return r.prepare(`
        INSERT INTO platforms (id, name, platform, credentials, status, updated_at)
        VALUES (@id, @name, @platform, @credentials, 'configured', datetime('now'))
        ON CONFLICT(id) DO UPDATE SET
          name = @name,
          platform = @platform,
          credentials = @credentials,
          status = 'configured',
          updated_at = datetime('now')
      `).run(e),!0}catch(e){return console.error("[DAL] Platform upsert error:",e),!1}},updateStatus(e,r){let a=(0,t.getDb)();try{return a.prepare("UPDATE platforms SET status = ?, updated_at = datetime('now') WHERE id = ?").run(r,e),!0}catch(e){return console.error("[DAL] Platform updateStatus error:",e),!1}},delete(e){let r=(0,t.getDb)();try{return r.prepare("DELETE FROM platforms WHERE id = ?").run(e),!0}catch(e){return console.error("[DAL] Platform delete error:",e),!1}}}])},7064,e=>{"use strict";var t=e.i(2710),r=e.i(35147),a=e.i(55688),s=e.i(87453),o=e.i(3771),n=e.i(47937),i=e.i(5457),d=e.i(17598),l=e.i(41045),T=e.i(71952),p=e.i(59300),u=e.i(85005),c=e.i(69628),E=e.i(3185),m=e.i(47811),A=e.i(93695);e.i(635);var R=e.i(28214),f=e.i(78869),h=e.i(42203);async function L(){try{let e=h.PlatformDAL.getAll();return f.NextResponse.json({success:!0,data:e.map(e=>({...e,credentials:JSON.parse(e.credentials||"{}")}))})}catch(e){return console.error("[API] GET /api/v1/platforms error:",e),f.NextResponse.json({success:!1,error:"获取平台配置失败"},{status:500})}}async function _(e){try{let{platform:t,name:r,credentials:a}=await e.json();if(!t||!a)return f.NextResponse.json({success:!1,error:"缺少必要参数：platform, credentials"},{status:400});if(h.PlatformDAL.upsert({id:t,name:r||t,platform:t,credentials:JSON.stringify(a)}))return f.NextResponse.json({success:!0,message:"保存成功"});return f.NextResponse.json({success:!1,error:"保存失败"},{status:500})}catch(e){return console.error("[API] POST /api/v1/platforms error:",e),f.NextResponse.json({success:!1,error:"保存平台配置失败"},{status:500})}}e.i(84501),e.s(["GET",()=>L,"POST",()=>_],70354);var g=e.i(70354);let N=new t.AppRouteRouteModule({definition:{kind:r.RouteKind.APP_ROUTE,page:"/api/v1/platforms/route",pathname:"/api/v1/platforms",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/src/app/api/v1/platforms/route.ts",nextConfigOutput:"standalone",userland:g}),{workAsyncStorage:x,workUnitAsyncStorage:X,serverHooks:D}=N;function U(){return(0,a.patchFetch)({workAsyncStorage:x,workUnitAsyncStorage:X})}async function w(e,t,a){N.isDev&&(0,s.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let f="/api/v1/platforms/route";f=f.replace(/\/index$/,"")||"/";let h=await N.prepare(e,t,{srcPage:f,multiZoneDraftMode:!1});if(!h)return t.statusCode=400,t.end("Bad Request"),null==a.waitUntil||a.waitUntil.call(a,Promise.resolve()),null;let{buildId:L,params:_,nextConfig:g,parsedUrl:x,isDraftMode:X,prerenderManifest:D,routerServerContext:U,isOnDemandRevalidate:w,revalidateOnlyGenerated:v,resolvedPathname:y,clientReferenceManifest:O,serverActionsManifest:S}=h,I=(0,i.normalizeAppPath)(f),C=!!(D.dynamicRoutes[I]||D.routes[y]),F=async()=>((null==U?void 0:U.render404)?await U.render404(e,t,x,!1):t.end("This page could not be found"),null);if(C&&!X){let e=!!D.routes[y],t=D.dynamicRoutes[I];if(t&&!1===t.fallback&&!e){if(g.experimental.adapterPath)return await F();throw new A.NoFallbackError}}let b=null;!C||N.isDev||X||(b="/index"===(b=y)?"/":b);let P=!0===N.isDev||!C,k=C&&!P;S&&O&&(0,n.setManifestsSingleton)({page:f,clientReferenceManifest:O,serverActionsManifest:S});let M=e.method||"GET",j=(0,o.getTracer)(),q=j.getActiveScopeSpan(),H={params:_,prerenderManifest:D,renderOpts:{experimental:{authInterrupts:!!g.experimental.authInterrupts},cacheComponents:!!g.cacheComponents,supportsDynamicResponse:P,incrementalCache:(0,s.getRequestMeta)(e,"incrementalCache"),cacheLifeProfiles:g.cacheLife,waitUntil:a.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,r,a,s)=>N.onRequestError(e,t,a,s,U)},sharedContext:{buildId:L}},B=new d.NodeNextRequest(e),K=new d.NodeNextResponse(t),G=l.NextRequestAdapter.fromNodeNextRequest(B,(0,l.signalFromNodeResponse)(t));try{let n=async e=>N.handle(G,H).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let r=j.getRootSpanAttributes();if(!r)return;if(r.get("next.span_type")!==T.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${r.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let a=r.get("next.route");if(a){let t=`${M} ${a}`;e.setAttributes({"next.route":a,"http.route":a,"next.span_name":t}),e.updateName(t)}else e.updateName(`${M} ${f}`)}),i=!!(0,s.getRequestMeta)(e,"minimalMode"),d=async s=>{var o,d;let l=async({previousCacheEntry:r})=>{try{if(!i&&w&&v&&!r)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let o=await n(s);e.fetchMetrics=H.renderOpts.fetchMetrics;let d=H.renderOpts.pendingWaitUntil;d&&a.waitUntil&&(a.waitUntil(d),d=void 0);let l=H.renderOpts.collectedTags;if(!C)return await (0,u.sendResponse)(B,K,o,H.renderOpts.pendingWaitUntil),null;{let e=await o.blob(),t=(0,c.toNodeOutgoingHttpHeaders)(o.headers);l&&(t[m.NEXT_CACHE_TAGS_HEADER]=l),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let r=void 0!==H.renderOpts.collectedRevalidate&&!(H.renderOpts.collectedRevalidate>=m.INFINITE_CACHE)&&H.renderOpts.collectedRevalidate,a=void 0===H.renderOpts.collectedExpire||H.renderOpts.collectedExpire>=m.INFINITE_CACHE?void 0:H.renderOpts.collectedExpire;return{value:{kind:R.CachedRouteKind.APP_ROUTE,status:o.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:r,expire:a}}}}catch(t){throw(null==r?void 0:r.isStale)&&await N.onRequestError(e,t,{routerKind:"App Router",routePath:f,routeType:"route",revalidateReason:(0,p.getRevalidateReason)({isStaticGeneration:k,isOnDemandRevalidate:w})},!1,U),t}},T=await N.handleResponse({req:e,nextConfig:g,cacheKey:b,routeKind:r.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:D,isRoutePPREnabled:!1,isOnDemandRevalidate:w,revalidateOnlyGenerated:v,responseGenerator:l,waitUntil:a.waitUntil,isMinimalMode:i});if(!C)return null;if((null==T||null==(o=T.value)?void 0:o.kind)!==R.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==T||null==(d=T.value)?void 0:d.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});i||t.setHeader("x-nextjs-cache",w?"REVALIDATED":T.isMiss?"MISS":T.isStale?"STALE":"HIT"),X&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let A=(0,c.fromNodeOutgoingHttpHeaders)(T.value.headers);return i&&C||A.delete(m.NEXT_CACHE_TAGS_HEADER),!T.cacheControl||t.getHeader("Cache-Control")||A.get("Cache-Control")||A.set("Cache-Control",(0,E.getCacheControlHeader)(T.cacheControl)),await (0,u.sendResponse)(B,K,new Response(T.value.body,{headers:A,status:T.value.status||200})),null};q?await d(q):await j.withPropagatedContext(e.headers,()=>j.trace(T.BaseServerSpan.handleRequest,{spanName:`${M} ${f}`,kind:o.SpanKind.SERVER,attributes:{"http.method":M,"http.target":e.url}},d))}catch(t){if(t instanceof A.NoFallbackError||await N.onRequestError(e,t,{routerKind:"App Router",routePath:I,routeType:"route",revalidateReason:(0,p.getRevalidateReason)({isStaticGeneration:k,isOnDemandRevalidate:w})},!1,U),C)throw t;return await (0,u.sendResponse)(B,K,new Response(null,{status:500})),null}}e.s(["handler",()=>w,"patchFetch",()=>U,"routeModule",()=>N,"serverHooks",()=>D,"workAsyncStorage",()=>x,"workUnitAsyncStorage",()=>X],7064)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__722ebb97._.js.map