module.exports=[96925,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_erp_products_%5Bid%5D_route_actions_1d5936c6.js.map