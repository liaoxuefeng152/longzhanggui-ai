module.exports=[645,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_erp_purchases_route_actions_75612681.js.map