module.exports=[70406,(e,t,r)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},93695,(e,t,r)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},18622,(e,t,r)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},24725,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},14747,(e,t,r)=>{t.exports=e.x("path",()=>require("path"))},94824,(e,t,r)=>{t.exports=e.x("better-sqlite3-6af3159004069310",()=>require("better-sqlite3-6af3159004069310"))},22734,(e,t,r)=>{t.exports=e.x("fs",()=>require("fs"))},84501,e=>{"use strict";var t=e.i(94824),r=e.i(14747),a=e.i(22734);let n=r.default.join(process.cwd(),"data","lobster.db"),o=r.default.dirname(n);a.default.existsSync(o)||a.default.mkdirSync(o,{recursive:!0});let s=null;function i(){return s||((s=new t.default(n)).pragma("journal_mode = WAL"),s.pragma("foreign_keys = ON"),function(e){e.exec(`
    CREATE TABLE IF NOT EXISTS platforms (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      platform TEXT NOT NULL,
      credentials TEXT DEFAULT '{}',
      status TEXT DEFAULT 'disconnected',
      last_sync TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    )
  `),e.exec(`
    CREATE TABLE IF NOT EXISTS miaoshou_config (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      phone TEXT NOT NULL,
      password TEXT NOT NULL,
      cookies TEXT,
      status TEXT DEFAULT 'disconnected',
      last_sync TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    )
  `);try{e.exec("ALTER TABLE miaoshou_config ADD COLUMN app_key TEXT"),e.exec("ALTER TABLE miaoshou_config ADD COLUMN app_secret TEXT")}catch(e){}e.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      username TEXT NOT NULL UNIQUE,
      password TEXT NOT NULL,
      email TEXT,
      role TEXT DEFAULT 'client',
      avatar TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    )
  `),e.exec(`
    CREATE TABLE IF NOT EXISTS products (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      name_en TEXT,
      sku TEXT,
      category TEXT,
      cost_price REAL DEFAULT 0,
      price REAL DEFAULT 0,
      stock INTEGER DEFAULT 0,
      status TEXT DEFAULT 'draft',
      source TEXT,
      source_url TEXT,
      supplier_name TEXT,
      supplier_id TEXT,
      images TEXT DEFAULT '[]',
      video_url TEXT,
      weight REAL,
      dimensions TEXT,
      description TEXT,
      description_en TEXT,
      keywords TEXT,
      attributes TEXT DEFAULT '{}',
      shop_id TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    )
  `),e.exec(`
    CREATE TABLE IF NOT EXISTS collection_products (
      id TEXT PRIMARY KEY,
      collection_id TEXT,
      product_id TEXT,
      product_name TEXT NOT NULL,
      source TEXT,
      source_url TEXT,
      source_id TEXT,
      supplier_name TEXT,
      cost_price REAL DEFAULT 0,
      images TEXT DEFAULT '[]',
      category TEXT,
      claimed INTEGER DEFAULT 0,
      claimed_by TEXT,
      claimed_at TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    )
  `),e.exec(`
    CREATE TABLE IF NOT EXISTS feishu_config (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      app_id TEXT NOT NULL,
      app_secret TEXT NOT NULL,
      bot_name TEXT,
      webhook_url TEXT,
      push_enabled INTEGER DEFAULT 0,
      alert_enabled INTEGER DEFAULT 1,
      alert_threshold INTEGER DEFAULT 10,
      templates TEXT DEFAULT '{}',
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    )
  `),e.exec(`
    CREATE TABLE IF NOT EXISTS import_history (
      id TEXT PRIMARY KEY,
      type TEXT NOT NULL,
      file_name TEXT,
      status TEXT DEFAULT 'pending',
      total_rows INTEGER DEFAULT 0,
      success_rows INTEGER DEFAULT 0,
      error_rows INTEGER DEFAULT 0,
      error_log TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      completed_at TEXT
    )
  `),0===e.prepare("SELECT COUNT(*) as count FROM users WHERE role = ?").get("admin").count&&e.prepare(`
      INSERT INTO users (id, username, password, email, role) VALUES (?, ?, ?, ?, ?)
    `).run("admin","admin","admin123","admin@example.com","admin"),0===e.prepare("SELECT COUNT(*) as count FROM feishu_config").get().count&&e.prepare(`
      INSERT INTO feishu_config (app_id, app_secret, bot_name, push_enabled, alert_enabled)
      VALUES (?, ?, ?, ?, ?)
    `).run("","","龙掌柜跨境AI全能助手",0,1),console.log("[DB] Database tables initialized")}(s)),s}e.s(["getDb",()=>i])},93647,e=>{"use strict";var t=e.i(2710),r=e.i(35147),a=e.i(55688),n=e.i(87453),o=e.i(3771),s=e.i(47937),i=e.i(5457),l=e.i(17598),c=e.i(41045),T=e.i(71952),d=e.i(59300),u=e.i(85005),p=e.i(69628),E=e.i(3185),h=e.i(47811),g=e.i(93695);e.i(635);var R=e.i(28214),m=e.i(78869),_=e.i(84501);async function A(){try{return(0,_.getDb)().prepare("SELECT * FROM feishu_config WHERE id = 1").get()||null}catch(e){return console.error("[飞书] 获取配置失败:",e),null}}async function f(e){try{console.log("[飞书] 调用AI服务...");let t=await fetch("http://localhost:8000/api/v1/ai/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message:e,user_id:"feishu_user"})});if(!t.ok)throw Error(`AI服务返回错误: ${t.status}`);let r=await t.json();return console.log("[飞书] AI响应数据:",JSON.stringify(r).substring(0,200)),r.reply||r.content||r.message||r.response||"处理成功"}catch(e){throw console.error("[飞书] AI调用失败:",e),e}}async function x(e,t,r){try{return await f(e)}catch(e){return console.error("[飞书] AI回复生成失败:",e),"消息已收到，正在处理中..."}}async function N(e){(0,_.getDb)();let t=e.nextUrl.searchParams.get("challenge");return t?(console.log("[飞书] URL验证请求"),new m.NextResponse(t,{status:200})):m.NextResponse.json({error:"Not found"},{status:404})}async function L(e){try{let t=await e.json();if(console.log("[飞书] 收到事件:",JSON.stringify(t).substring(0,500)),"url_verification"===t.type)return console.log("[飞书] URL验证通过"),new m.NextResponse(t.challenge,{status:200});let r=t.header?.event_type;if(console.log("[飞书] 事件类型:",r),"im.message.receive_v1"!==r)return console.log("[飞书] 非消息事件，跳过"),m.NextResponse.json({code:0});let a=t.event;if(!a)return console.log("[飞书] 无事件数据"),m.NextResponse.json({code:0});let n=a.message?.message_type;if(console.log("[飞书] 消息类型:",n),"text"!==n)return console.log("[飞书] 非文本消息，跳过"),m.NextResponse.json({code:0});let o=a.message?.chat_id,s=a.message?.message_id,i=a.message?.content,l="";try{l=JSON.parse(i).text||""}catch{l=i}if(l=l.replace(/@_user_1\s*/g,"").trim(),console.log("[飞书] 解析后消息:",l),console.log("[飞书] chat_id:",o),console.log("[飞书] message_id:",s),!l)return console.log("[飞书] 空消息，跳过"),m.NextResponse.json({code:0});console.log("[飞书] 开始生成AI回复...");let c=await x(l,"","");console.log("[飞书] AI回复:",c.substring(0,200)),console.log("[飞书] 准备发送回复到:",o);let T=await A();if(!T)return console.error("[飞书] 未配置飞书"),m.NextResponse.json({error:"未配置飞书"},{status:500});let d=T.app_id||"",u=T.app_secret||"",p=await fetch("https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({app_id:d,app_secret:u})}),E=(await p.json()).tenant_access_token;if(!E)return console.error("[飞书] 获取access_token失败"),m.NextResponse.json({error:"获取token失败"},{status:500});console.log("[飞书] 获取token成功");let h=await fetch("https://open.feishu.cn/open-apis/im/v1/messages?receive_id_type=chat_id",{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${E}`},body:JSON.stringify({receive_id:o,msg_type:"text",content:JSON.stringify({text:c})})}),g=await h.json();if(console.log("[飞书] 发送结果:",JSON.stringify(g).substring(0,200)),0===g.code)return console.log("[飞书] ✅ 消息发送成功!"),m.NextResponse.json({code:0,message:"success"});return console.error("[飞书] ❌ 发送失败:",g.msg),m.NextResponse.json(g,{status:500})}catch(e){return console.error("[飞书] 处理异常:",e),m.NextResponse.json({error:"Internal error"},{status:500})}}e.s(["GET",()=>N,"POST",()=>L],79313);var X=e.i(79313);let w=new t.AppRouteRouteModule({definition:{kind:r.RouteKind.APP_ROUTE,page:"/api/webhook/event/route",pathname:"/api/webhook/event",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/src/app/api/webhook/event/route.ts",nextConfigOutput:"standalone",userland:X}),{workAsyncStorage:y,workUnitAsyncStorage:U,serverHooks:v}=w;function O(){return(0,a.patchFetch)({workAsyncStorage:y,workUnitAsyncStorage:U})}async function I(e,t,a){w.isDev&&(0,n.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let m="/api/webhook/event/route";m=m.replace(/\/index$/,"")||"/";let _=await w.prepare(e,t,{srcPage:m,multiZoneDraftMode:!1});if(!_)return t.statusCode=400,t.end("Bad Request"),null==a.waitUntil||a.waitUntil.call(a,Promise.resolve()),null;let{buildId:A,params:f,nextConfig:x,parsedUrl:N,isDraftMode:L,prerenderManifest:X,routerServerContext:y,isOnDemandRevalidate:U,revalidateOnlyGenerated:v,resolvedPathname:O,clientReferenceManifest:I,serverActionsManifest:b}=_,D=(0,i.normalizeAppPath)(m),C=!!(X.dynamicRoutes[D]||X.routes[O]),S=async()=>((null==y?void 0:y.render404)?await y.render404(e,t,N,!1):t.end("This page could not be found"),null);if(C&&!L){let e=!!X.routes[O],t=X.dynamicRoutes[D];if(t&&!1===t.fallback&&!e){if(x.experimental.adapterPath)return await S();throw new g.NoFallbackError}}let F=null;!C||w.isDev||L||(F="/index"===(F=O)?"/":F);let k=!0===w.isDev||!C,j=C&&!k;b&&I&&(0,s.setManifestsSingleton)({page:m,clientReferenceManifest:I,serverActionsManifest:b});let P=e.method||"GET",M=(0,o.getTracer)(),q=M.getActiveScopeSpan(),H={params:f,prerenderManifest:X,renderOpts:{experimental:{authInterrupts:!!x.experimental.authInterrupts},cacheComponents:!!x.cacheComponents,supportsDynamicResponse:k,incrementalCache:(0,n.getRequestMeta)(e,"incrementalCache"),cacheLifeProfiles:x.cacheLife,waitUntil:a.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,r,a,n)=>w.onRequestError(e,t,a,n,y)},sharedContext:{buildId:A}},B=new l.NodeNextRequest(e),K=new l.NodeNextResponse(t),G=c.NextRequestAdapter.fromNodeNextRequest(B,(0,c.signalFromNodeResponse)(t));try{let s=async e=>w.handle(G,H).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let r=M.getRootSpanAttributes();if(!r)return;if(r.get("next.span_type")!==T.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${r.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let a=r.get("next.route");if(a){let t=`${P} ${a}`;e.setAttributes({"next.route":a,"http.route":a,"next.span_name":t}),e.updateName(t)}else e.updateName(`${P} ${m}`)}),i=!!(0,n.getRequestMeta)(e,"minimalMode"),l=async n=>{var o,l;let c=async({previousCacheEntry:r})=>{try{if(!i&&U&&v&&!r)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let o=await s(n);e.fetchMetrics=H.renderOpts.fetchMetrics;let l=H.renderOpts.pendingWaitUntil;l&&a.waitUntil&&(a.waitUntil(l),l=void 0);let c=H.renderOpts.collectedTags;if(!C)return await (0,u.sendResponse)(B,K,o,H.renderOpts.pendingWaitUntil),null;{let e=await o.blob(),t=(0,p.toNodeOutgoingHttpHeaders)(o.headers);c&&(t[h.NEXT_CACHE_TAGS_HEADER]=c),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let r=void 0!==H.renderOpts.collectedRevalidate&&!(H.renderOpts.collectedRevalidate>=h.INFINITE_CACHE)&&H.renderOpts.collectedRevalidate,a=void 0===H.renderOpts.collectedExpire||H.renderOpts.collectedExpire>=h.INFINITE_CACHE?void 0:H.renderOpts.collectedExpire;return{value:{kind:R.CachedRouteKind.APP_ROUTE,status:o.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:r,expire:a}}}}catch(t){throw(null==r?void 0:r.isStale)&&await w.onRequestError(e,t,{routerKind:"App Router",routePath:m,routeType:"route",revalidateReason:(0,d.getRevalidateReason)({isStaticGeneration:j,isOnDemandRevalidate:U})},!1,y),t}},T=await w.handleResponse({req:e,nextConfig:x,cacheKey:F,routeKind:r.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:X,isRoutePPREnabled:!1,isOnDemandRevalidate:U,revalidateOnlyGenerated:v,responseGenerator:c,waitUntil:a.waitUntil,isMinimalMode:i});if(!C)return null;if((null==T||null==(o=T.value)?void 0:o.kind)!==R.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==T||null==(l=T.value)?void 0:l.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});i||t.setHeader("x-nextjs-cache",U?"REVALIDATED":T.isMiss?"MISS":T.isStale?"STALE":"HIT"),L&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let g=(0,p.fromNodeOutgoingHttpHeaders)(T.value.headers);return i&&C||g.delete(h.NEXT_CACHE_TAGS_HEADER),!T.cacheControl||t.getHeader("Cache-Control")||g.get("Cache-Control")||g.set("Cache-Control",(0,E.getCacheControlHeader)(T.cacheControl)),await (0,u.sendResponse)(B,K,new Response(T.value.body,{headers:g,status:T.value.status||200})),null};q?await l(q):await M.withPropagatedContext(e.headers,()=>M.trace(T.BaseServerSpan.handleRequest,{spanName:`${P} ${m}`,kind:o.SpanKind.SERVER,attributes:{"http.method":P,"http.target":e.url}},l))}catch(t){if(t instanceof g.NoFallbackError||await w.onRequestError(e,t,{routerKind:"App Router",routePath:D,routeType:"route",revalidateReason:(0,d.getRevalidateReason)({isStaticGeneration:j,isOnDemandRevalidate:U})},!1,y),C)throw t;return await (0,u.sendResponse)(B,K,new Response(null,{status:500})),null}}e.s(["handler",()=>I,"patchFetch",()=>O,"routeModule",()=>w,"serverHooks",()=>v,"workAsyncStorage",()=>y,"workUnitAsyncStorage",()=>U],93647)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__66b98db8._.js.map